/////////////////////////////////////////////////////////////////////////////
/// @file CnCurve.h
///
/// @author Daniel Wilczak
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) 2000-2012 by the CAPD Group.
//
// This file constitutes a part of the CAPD library,
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.ii.uj.edu.pl/ for details.

#ifndef _CAPD_DIFFALGEBRA_CNCURVE_H_
#define _CAPD_DIFFALGEBRA_CNCURVE_H_

#include <stdexcept>
#include "capd/diffAlgebra/Curve.h"

namespace capd{
namespace diffAlgebra{
/// @addtogroup diffAlgebra
/// @{
/**
 * This class provides methods for evaluation of the parametric curve
 * for a given parameter value.
 *
 * Template parameter BaseCurveT must provide storage and access for coefficients.
 */

template <class BaseCurveT >
class CnCurve : public Curve<BaseCurveT>{
public:
  typedef typename BaseCurveT::HessianType HessianType;
  typedef typename BaseCurveT::MatrixType MatrixType;
  typedef typename MatrixType::RowVectorType VectorType;
  typedef typename MatrixType::ScalarType ScalarType;
  typedef typename TypeTraits<ScalarType>::Real Real;

  CnCurve(Real left, Real right, int dimension, int order)
    : Curve<BaseCurveT>(left,right,dimension,order)
  {}
  HessianType hessian(const ScalarType& h) const;

};

///@}
}} // namespace capd::diffAlgebra

#endif // _CAPD_DIFFALGEBRA_CNCURVE_H_
