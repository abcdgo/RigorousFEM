/////////////////////////////////////////////////////////////////////////////
/// @file FadCurve.h
///
/// @author Daniel Wilczak
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) 2000-2012 by the CAPD Group.
//
// This file constitutes a part of the CAPD library,
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.ii.uj.edu.pl/ for details.

#ifndef _CAPD_DIFFALGEBRA_FADCURVE_H_
#define _CAPD_DIFFALGEBRA_FADCURVE_H_

#include <stdexcept>
#include "capd/basicalg/TypeTraits.h"
#include "capd/fadbad/fadbad.h"
#include "capd/fadbad/fadiff.h"
#include "capd/fadbad/tadiff.h"

namespace capd{
namespace diffAlgebra{
/// @addtogroup diffAlgebra
/// @{

template < class MatrixT, int D=0 >
class FadCurve {
public:
  // general typedefs required for the interface
  typedef MatrixT MatrixType;
  typedef typename MatrixType::RowVectorType VectorType;
  typedef typename MatrixType::ScalarType ScalarType;
  typedef typename TypeTraits<ScalarType>::Real Real;

  // own typedefs
  typedef fadbad::T<ScalarType> TScalar;
  typedef fadbad::F<ScalarType,D> FScalar;
  typedef fadbad::T<FScalar> TFScalar;
  typedef typename VectorType::template rebind<TFScalar>::other TFVector;
  typedef typename VectorType::template rebind<TScalar>::other TVector;

  FadCurve(int dimension, int order);

  virtual void setOrder(int order); ///< Sets the order of Taylor interpolation
  int getOrder() const;             ///< Returns the order of Taylor interpolation
  int getAllocatedOrder() const;    ///< Returns maximal allocated order - used to avoid memory reallocation
  int dimension() const;            ///< Returns the dimension in which the parametric curve is embedded

  void clearCoefficients();             ///< sets all coefficients to zero
  void derivative(FadCurve& out) const; ///< computes time derivative of curve as a curve

  const ScalarType& centerCoefficient(int i, int j) const;
  const ScalarType& coefficient(int i, int j) const;
  const ScalarType& remainderCoefficient(int i, int j) const;
  const ScalarType& coefficient(int i, int j, int k) const;
  const ScalarType& remainderCoefficient(int i, int j, int k) const;

  ScalarType& centerCoefficient(int i, int j);
  ScalarType& coefficient(int i, int j);
  ScalarType& remainderCoefficient(int i, int j);
  ScalarType& coefficient(int i, int j, int k);
  ScalarType& remainderCoefficient(int i, int j, int k);

protected:

  int m_order;
  int m_dimension;

  mutable TVector m_center;
  mutable TFVector m_in;
  mutable TVector m_rem;
  mutable TFVector m_jacRem;

};

//###########################################################//

template < class MatrixT, int D >
inline
int FadCurve<MatrixT,D>::getOrder() const
{
  return m_order;
}

template < class MatrixT, int D >
inline
int FadCurve<MatrixT,D>::getAllocatedOrder() const
{
  return MaxLength;
}

template < class MatrixT, int D >
inline
int FadCurve<MatrixT,D>::dimension() const
{
  return m_dimension;
}

// -----------------------------------------------------------------------------

template < class MatrixT, int D >
inline
const typename MatrixT::ScalarType& FadCurve<MatrixT,D>::centerCoefficient(int i, int r) const{
  return m_center[i][r];
}

template < class MatrixT, int D >
inline
const typename MatrixT::ScalarType& FadCurve<MatrixT,D>::coefficient(int i, int r) const{
  return m_in[i][r].x();
}

template < class MatrixT, int D >
inline
const typename MatrixT::ScalarType& FadCurve<MatrixT,D>::remainderCoefficient(int i, int r) const{
  return m_rem[i][r];
}

template < class MatrixT, int D >
inline
const typename MatrixT::ScalarType& FadCurve<MatrixT,D>::coefficient(int i, int j, int r) const{
  return m_in[i][r].d(j);
}

template < class MatrixT, int D >
inline
const typename MatrixT::ScalarType& FadCurve<MatrixT,D>::remainderCoefficient(int i, int j, int r) const{
  return m_jacRem[i][r].d(j);
}


// -----------------------------------------------------------------------------

template < class MatrixT, int D >
inline
typename MatrixT::ScalarType& FadCurve<MatrixT,D>::centerCoefficient(int i, int r) {
  return m_center[i][r];
}

template < class MatrixT, int D >
inline
typename MatrixT::ScalarType& FadCurve<MatrixT,D>::coefficient(int i, int r) {
  return m_in[i][r].x();
}

template < class MatrixT, int D >
inline
typename MatrixT::ScalarType& FadCurve<MatrixT,D>::remainderCoefficient(int i, int r) {
  return m_rem[i][r];
}

template < class MatrixT, int D >
inline
typename MatrixT::ScalarType& FadCurve<MatrixT,D>::coefficient(int i, int j, int r) {
  return m_in[i][r].d(j);
}

template < class MatrixT, int D >
inline
typename MatrixT::ScalarType& FadCurve<MatrixT,D>::remainderCoefficient(int i, int j, int r) {
  return m_jacRem[i][r].d(j);
}

///@}
}} // namespace capd::diffAlgebra

#endif // _CAPD_DIFFALGEBRA_FADCURVE_H_
