/////////////////////////////////////////////////////////////////////////////
/// @file CnCurve.hpp
///
/// @author Daniel Wilczak
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) 2000-2012 by the CAPD Group.
//
// This file constitutes a part of the CAPD library,
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.ii.uj.edu.pl/ for details.

#ifndef _CAPD_DIFFALGEBRA_CNCURVE_HPP_
#define _CAPD_DIFFALGEBRA_CNCURVE_HPP_

#include <stdexcept>
#include "capd/diffAlgebra/CnCurve.h"
#include "capd/diffAlgebra/Curve.hpp"
#include "capd/diffAlgebra/BasicCnCurve.hpp"

namespace capd{
namespace diffAlgebra{

template <class BaseCurveT >
typename CnCurve<BaseCurveT>::HessianType CnCurve<BaseCurveT>::hessian(const ScalarType& h) const
{
  if((h>=this->m_left) and (h<=this->m_right))
  {
    int p = this->getOrder();
    HessianType result(this->dimension());
    for(int p = this->getOrder();p>=0;--p)
      for(int i=0;i<this->dimension();++i)
        for(int j=0;j<this->dimension();++j)
          for(int c=j;c<this->dimension();++j)
            result(i,j,c) = result(i,j,c)*h + this->coefficient(i,j,c,p);

    if(capd::TypeTraits<ScalarType>::isInterval) {
      ScalarType c = power(h,this->getOrder()+1);
      typename HessianType::iterator i1 = result.begin(), i2 = result.end();
      for(int i=0;i<this->dimension();++i)
        for(int j=0;j<this->dimension();++j)
          for(int c=j;c<this->dimension();++j)
            result(i,j,c) = result(i,j,c)*h + this->remainderCoefficient(i,j,c,this->getOrder()+1);
    }
    return result;
  }
  throw std::domain_error("capd::diffAlgebra::CnCurve::hessian(t) error - argument t is out of domain");

}

///@}
}} // namespace capd::diffAlgebra

#endif // _CAPD_DIFFALGEBRA_CNCURVE_H_
