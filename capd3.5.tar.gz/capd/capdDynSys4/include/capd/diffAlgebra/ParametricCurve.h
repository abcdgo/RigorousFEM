/////////////////////////////////////////////////////////////////////////////
/// @file ParametricCurve.h
///
/// @author Daniel Wilczak
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) 2000-2013 by the CAPD Group.
//
// This file constitutes a part of the CAPD library,
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.ii.uj.edu.pl/ for details.

#ifndef _CAPD_DIFFALGEBRA_PARAMETRICCURVE_H_
#define _CAPD_DIFFALGEBRA_PARAMETRICCURVE_H_

#include <stdexcept>
#include <vector>
#include "capd/basicalg/TypeTraits.h"
#include "capd/diffAlgebra/Hessian.h"

/**
 * This file defines an abstract class that represents parametric curve in \f$R^n\f$.
 * We do not specify how it is represented in the memory.
 *
 * The curve can be evaluated at given time 't' as well as differentiated with respect to 't'.
 *
 * The curve can store rigorous enclosures of curves.
 *
 * The main template parameter is an abstract class that represent a piece of curve as one polynomial.
 */

namespace capd{
namespace diffAlgebra{


// ##########################################################

template<class MatrixT>
class ParametricCurve{
public:
  typedef MatrixT MatrixType;
  typedef typename MatrixType::RowVectorType VectorType;
  typedef typename MatrixType::ScalarType ScalarType;
  typedef typename TypeTraits<ScalarType>::Real Real;
  typedef Hessian<ScalarType,VectorType::csDim,VectorType::csDim> HessianType;

  virtual ~ParametricCurve(){}
  virtual Real getLeftDomain() const = 0;
  virtual Real getRightDomain() const = 0;

  virtual VectorType operator()(const ScalarType& h) const = 0;
  virtual MatrixType operator[](const ScalarType& h) const = 0;
  virtual HessianType hessian(const ScalarType& h) const = 0;
  virtual VectorType valueAtCenter(const ScalarType& h) const = 0;

  // the implementation should provide also a template operator
  // that computes higher order derivatives of curve c(t,x) wrt to initial point x
  //template<class CnCoeffT>
  //CnCoeffT jet(const ScalarType& h) const;
};

}} // namespace capd::diffAlgebra

#endif
