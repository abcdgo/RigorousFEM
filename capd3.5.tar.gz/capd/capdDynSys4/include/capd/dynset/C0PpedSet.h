/////////////////////////////////////////////////////////////////////////////
/// @file C0PpedSet.h
///
/// @author The CAPD Group
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) 2000-2005 by the CAPD Group.
//
// This file constitutes a part of the CAPD library,
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.ii.uj.edu.pl/ for details.

#ifndef _CAPD_DYNSET_C0PPEDSET_H_
#define _CAPD_DYNSET_C0PPEDSET_H_

#include "capd/dynset/C0AffineSet.hpp"
#include "capd/dynset/QRPolicy.h"


namespace capd{
namespace dynset{
/// @addtogroup dynset
/// @{

////////////////////////////////////////////////////////////////////////////////////
//
///
/// C0PpedSet is represented as : x + B*r.
///
/// It is moved via inverse matrix - Lohner second method
///
////////////////////////////////////////////////////////////////////////////////////

typedef InverseQRPolicy<> PpedPolicies;

template<typename MatrixT>
class C0PpedSet : public C0AffineSet<MatrixT,PpedPolicies>
{
public:
  typedef MatrixT MatrixType;
  typedef typename MatrixType::RowVectorType VectorType;
  typedef typename MatrixType::ScalarType ScalarType;
  typedef C0AffineSet<MatrixT,PpedPolicies> BaseSet;

  std::string name() { return "C0PpedSet"; }
  C0PpedSet(const BaseSet& s) : BaseSet(s) {}
};
/// @}


}} // namespace capd::dynset

#endif // _CAPD_DYNSET_C0PPEDSET_H_
