/////////////////////////////////////////////////////////////////////////////
/// @file C0RectSet.h
///
/// @author The CAPD Group
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) 2000-2005 by the CAPD Group.
//
// This file constitutes a part of the CAPD library,
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.ii.uj.edu.pl/ for details.

#ifndef _CAPD_DYNSET_C0RECTSET_H_
#define _CAPD_DYNSET_C0RECTSET_H_

#include "capd/dynset/C0AffineSet.hpp"
#include "capd/dynset/QRPolicy.h"

namespace capd{
namespace dynset{
/// @addtogroup dynset
/// @{


/**
 *  C0RectSet  set is represented as  x + B*r
 *
 *  where
 *    x - center point
 *    B - matrix ('change of coordinates')
 *    r - interval set (almost zero centered product of intervals)
 *
 *  Set is moved via "QR-decomposition".
 *  @see P.Zgliczynski "C^1-Lohner algorithm".
 */

typedef FullQRWithPivoting<>  RectPolicies;

template<typename MatrixT>
class C0RectSet : public C0AffineSet<MatrixT,RectPolicies> {
public:
  typedef MatrixT MatrixType;
  typedef typename MatrixType::RowVectorType VectorType;
  typedef typename MatrixType::ScalarType ScalarType;
  typedef C0AffineSet<MatrixT,RectPolicies> BaseSet;

  std::string name() { return "C0RectSet"; }
  C0RectSet(const BaseSet& s) : BaseSet(s) {}
};

/// @}

}} // namespace capd::dynset

#endif // _CAPD_DYNSET_C0RECTSET_H_

