/////////////////////////////////////////////////////////////////////////////
/// @file C0IntvSet.hpp
///
/// @author The CAPD Group
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) 2000-2005 by the CAPD Group.
//
// This file constitutes a part of the CAPD library, 
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.ii.uj.edu.pl/ for details. 

#ifndef _CAPD_DYNSET_C0INTVSET_HPP_
#define _CAPD_DYNSET_C0INTVSET_HPP_

#include "capd/dynset/C0IntvSet.h"
#include "capd/vectalg/iobject.hpp"
#include "capd/matrixAlgorithms/floatMatrixAlgorithms.hpp"

// move  by  Jac*x + remainder
namespace capd{
namespace dynset{

template<typename MatrixType>
C0IntvSet<MatrixType>::C0IntvSet(const VectorType& x, ScalarType t)
  : C0Set<MatrixType>(x,VectorType(x.dimension()),t),
    m_x(x), m_r(x.dimension())
{
  m_r.clear();
}

template<typename MatrixType>
C0IntvSet<MatrixType>::C0IntvSet(const VectorType& x, const VectorType& r, ScalarType t)
  : C0Set<MatrixType>(x+r,VectorType(x.dimension()),t),
    m_x(x), m_r(r)
{
  if(!subset(VectorType(x.dimension()),m_r))
  {
    m_x += m_r;
    split(m_x,m_r);
  }
}


template<typename MatrixType>
typename C0IntvSet<MatrixType>::ScalarType C0IntvSet<MatrixType>::size(void)
{
  return capd::vectalg::size(this->m_currentSet);
}

template<typename MatrixType>
void C0IntvSet<MatrixType>::move(capd::dynsys::DynSys<MatrixType>& dynsys)
{
  this->move(dynsys,*this);
}

template<typename MatrixType>
void C0IntvSet<MatrixType>::move(capd::dynsys::DynSys<MatrixType>& dynsys, C0IntvSet& result) const
{
  VectorType y(m_x.dimension()), rem(m_x.dimension()), enc(m_x.dimension());
  MatrixType A(m_x.dimension(), m_x.dimension());

  VectorType xx = VectorType(*this);
  // the following function can throw an exception leaving output parameters in an inconsistent state
  // do not overwrite parameters of the set until we are sure that they are computed correctly
  dynsys.encloseMap(this->getCurrentTime(),m_x, xx, y, rem, enc, A);

  result.m_currentSet = result.m_x = y + A*m_r + rem;
  split(result.m_x,result.m_r);
  result.setCurrentTime(this->getCurrentTime()+dynsys.getStep());
  result.setLastEnclosure(enc);
}

template<typename MatrixType>
std::string C0IntvSet<MatrixType>::show(void) const
{
  std::ostringstream descriptor;
  descriptor << "C0IntvSet: x=";
  descriptor << m_x << " r=";
  descriptor << m_r << " ";
  return descriptor.str();
}

template<typename MatrixType>
typename C0IntvSet<MatrixType>::VectorType C0IntvSet<MatrixType>::affineTransformation(
    const MatrixType& A_M, const VectorType& A_C
  ) const
{
  return A_M*(VectorType(*this)-A_C);
}

}} // namespace capd::dynset

#endif // _CAPD_DYNSET_C0INTERVALSET_HPP_
