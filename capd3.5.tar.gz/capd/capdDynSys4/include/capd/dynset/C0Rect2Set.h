/////////////////////////////////////////////////////////////////////////////
/// @file C0Rect2Set.h
///
/// @author The CAPD Group
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) 2000-2005 by the CAPD Group.
//
// This file constitutes a part of the CAPD library,
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.ii.uj.edu.pl/ for details.

#ifndef _CAPD_DYNSET_C0RECT2SET_H_
#define _CAPD_DYNSET_C0RECT2SET_H_

#include "capd/dynset/C0DoubletonSet.hpp"
#include "capd/dynset/QRPolicy.h"
#include "capd/dynset/reorganization/FactorReorganization.h"

namespace capd{
namespace dynset{
/// @addtogroup dynset
/// @{

/////////////////////////////////////////////////////////////////////
///
///  The set is represented as doubleton: x + C*r0 + B*r;
///  and is moved by Lohner last method.
///
///  internal representation :
///        C*r0 - basic 'Lipschitz part'
///        B*r  - QR-decomposition of the remaining errors
///
///////////////////////////////////////////////////////////////////////

typedef FactorReorganization<FullQRWithPivoting<> > C0Rect2Policies;


template<typename MatrixT>
class C0Rect2Set : public C0DoubletonSet<MatrixT,C0Rect2Policies> {
public:
  typedef MatrixT MatrixType;
  typedef typename MatrixType::RowVectorType VectorType;
  typedef typename MatrixType::ScalarType ScalarType;
  typedef C0DoubletonSet<MatrixT,C0Rect2Policies> BaseSet;

  std::string name() { return "C0Rect2Set"; }
  C0Rect2Set(const BaseSet& s) : BaseSet(s) {}
};

/// @}

}} // namespace capd::dynset

#endif // _CAPD_DYNSET_C0RECT2SET_H_
