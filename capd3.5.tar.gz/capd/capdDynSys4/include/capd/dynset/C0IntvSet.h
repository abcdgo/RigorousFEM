/////////////////////////////////////////////////////////////////////////////
/// @file C0IntvSet.h
///
/// @author The CAPD Group
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) 2000-2005 by the CAPD Group.
//
// This file constitutes a part of the CAPD library, 
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.ii.uj.edu.pl/ for details. 

#ifndef _CAPD_DYNSET_INTVSET_H_
#define _CAPD_DYNSET_INTVSET_H_

#include "capd/dynset/C0Set.h"
#include <string>

namespace capd{
namespace dynset{
/// @addtogroup dynset
/// @{

//////////////////////////////////////////////////////////////////
//
///
/// Set is represented as x + r
///
/// with center x and zero centered box r.
///
/// It is moved  by  Jac*x + remainder
///
//////////////////////////////////////////////////////////////////
template<typename MatrixT>
class C0IntvSet : public C0Set<MatrixT>
{
public:
  typedef MatrixT MatrixType;
  typedef typename MatrixType::RowVectorType VectorType;
  typedef typename MatrixType::ScalarType ScalarType;
  typedef capd::vectalg::Norm<VectorType,MatrixType> NormType;

  explicit C0IntvSet(const VectorType& x, ScalarType t = TypeTraits<ScalarType>::zero());
  C0IntvSet(const VectorType& x,const VectorType& r, ScalarType t = TypeTraits<ScalarType>::zero());

  virtual ScalarType size(void);
  void move(capd::dynsys::DynSys<MatrixType>& dynsys);
  void move(capd::dynsys::DynSys<MatrixType>& dynsys, C0IntvSet& result) const;
  virtual std::string show(void) const;
  virtual VectorType affineTransformation(const MatrixType&, const VectorType&) const;
  std::string name() const{
    return "C0IntvSet";
  }
protected:
  VectorType m_x, m_r;
public:
  const VectorType & get_x () const {return m_x;}
  const ScalarType & getElement_x (int i) const {return m_x[i];}
  void set_x (const VectorType & x) {m_x = x;}
  void setElement_x (int i, const ScalarType & s) {m_x[i] = s;}
  const VectorType & get_r () const {return m_r;}
  const ScalarType & getElement_r (int i) const {return m_r[i];}
  inline void set_r (const VectorType & r) {m_r = r;}
  inline void setElement_r (int i, const ScalarType & s) {m_r[i] = s;}

};
/// @}

}} // namespace capd::dynset

#endif // _CAPD_DYNSET_INTERVALSET_H_
