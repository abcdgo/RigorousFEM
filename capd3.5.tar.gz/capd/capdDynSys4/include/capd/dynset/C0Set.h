/////////////////////////////////////////////////////////////////////////////
/// @file C0Set.h
///
/// @author The CAPD Group
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) 2000-2012 by the CAPD Group.
//
// This file constitutes a part of the CAPD library,
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.ii.uj.edu.pl/ for details.

#ifndef _CAPD_DYNSET_C0SET_H_
#define _CAPD_DYNSET_C0SET_H_

#include <string>
#include <sstream>
#include <stdexcept>
#include "capd/diffAlgebra/TimeRange.h"
#include "capd/dynset/EnclosureHolder.h"
#include "capd/dynsys/DynSys.h"
#include "capd/dynset/SetTraits.h"

namespace capd{
/**
 * Various set representations that can be moved with dynamical systems
 */
namespace dynset{
/// @addtogroup dynset
/// @{

/**
 * Common interface of all sets that stores only C0 information (set position).
 */
template<typename MatrixT>
class C0Set : public capd::diffAlgebra::TimeRange<typename MatrixT::ScalarType>,
              public capd::dynset::C0EnclosureHolder<typename MatrixT::RowVectorType>
{
public:
  typedef MatrixT MatrixType;
  typedef typename MatrixType::RowVectorType VectorType;
  typedef typename MatrixType::ScalarType ScalarType;
  typedef C0Set SetType;                                   ///<  defines class of given set (C0, C1, C2, ...)
  typedef capd::dynsys::DynSys<MatrixType> DynSysType;     ///< defines minimal regularity of the dynamical system

  /// constructor, initializes default enclosure and initial time
  C0Set(const VectorType& x, const VectorType& enc, const ScalarType& t)
      : capd::diffAlgebra::TimeRange<ScalarType>(t),
        capd::dynset::C0EnclosureHolder<VectorType>(x,enc)
  {}

  /// destructor
  virtual ~C0Set (void) {}
    /// computes image of the set after one step/iterate of the dynamical system
  virtual void move(DynSysType& dynsys) = 0;
    /// returns a set detailed information
  virtual std::string show() const = 0;
  const static int degree() { return 0; }
};

/**
 * Specialization of Traits class
 */

template<class MatrixT>
struct SetTraits< C0Set<MatrixT> >{
	const static bool isC0Set=true;
	const static bool isC1Set=false;
	const static bool isC2Set=false;
	const static bool isCnSet=false;
};

/// @}
}} //namespace capd::dynset

#endif // _CAPD_DYNSET_C0SET_H_
