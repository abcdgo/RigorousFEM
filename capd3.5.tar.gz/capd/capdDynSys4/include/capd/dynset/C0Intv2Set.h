/////////////////////////////////////////////////////////////////////////////
/// @file C0Intv2Set.h
///
/// @author The CAPD Group
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) 2000-2005 by the CAPD Group.
//
// This file constitutes a part of the CAPD library, 
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.ii.uj.edu.pl/ for details. 

#ifndef _CAPD_DYNSET_C0INTV2SET_H_
#define _CAPD_DYNSET_C0INTV2SET_H_

#include "capd/dynset/C0DoubletonSet.h"
#include "capd/dynset/reorganization/FactorReorganization.h"

namespace capd{
namespace dynset{
/// @addtogroup dynset
/// @{

///
/// C0Intv2Set is represented as: x + C*r0 + r
///
/// Lohner - internal representation;
///   C*r0 - Lipschitz part
///   r  -  'errors' computed via interval evaluation

typedef FactorReorganization<> C0Intv2Policies;

template<typename MatrixT>
class C0Intv2Set : public C0DoubletonSet<MatrixT,C0Intv2Policies> {
public:
  typedef MatrixT MatrixType;
  typedef typename MatrixType::RowVectorType VectorType;
  typedef typename MatrixType::ScalarType ScalarType;
  typedef C0DoubletonSet<MatrixT,C0Intv2Policies> BaseSet;

  std::string name() { return "C0Intv2Set"; }
  C0Intv2Set(const BaseSet& s) : BaseSet(s) {}
};

/// @}

}} // namespace capd::dynset

#endif // _CAPD_DYNSET_C0INTV2SET_H_
