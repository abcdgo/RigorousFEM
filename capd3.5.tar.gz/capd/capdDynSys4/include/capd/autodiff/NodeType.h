/// @addtogroup autodiff
/// @{

/////////////////////////////////////////////////////////////////////////////
/// @file NodeType.h
///
/// @author Daniel Wilczak
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) 2000-2012 by the CAPD Group.
//
// This file constitutes a part of the CAPD library,
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.ii.uj.edu.pl/ for details.

#ifndef _CAPD_AUTODIFF_NODETYPE_H_
#define _CAPD_AUTODIFF_NODETYPE_H_
#include "capd/autodiff/DagIndexer.h"
namespace capd{
namespace autodiff{

// ANY change in NodeType MUST be synchronized with an array of functions file eval.hpp
enum NodeType {
// ------------------ ADD -------------------------------
    NODE_ADD=0                  , // f(x,y,..)*g(x,y,..)
    NODE_CONST_PLUS_VAR         , // const + f(x,y,..)
    NODE_CONST_PLUS_CONST       , // const1 + const2
    NODE_CONST_PLUS_TIME        , // const + time
    NODE_CONST_PLUS_FUNTIME     , // const + f(time)
    NODE_TIME_PLUS_VAR          , // time + f(x,y,..)
    NODE_TIME_PLUS_FUNTIME      , // time + f(time)
    NODE_FUNTIME_PLUS_VAR       , // f(time) + g(x,y,...)
    NODE_FUNTIME_PLUS_FUNTIME   , // f(time) + g(time)
// ------------------ SUB -------------------------------
    NODE_SUB                    ,
    NODE_CONST_MINUS_CONST      ,
    NODE_CONST_MINUS_VAR        ,
    NODE_CONST_MINUS_TIME       ,
    NODE_CONST_MINUS_FUNTIME    ,
    NODE_TIME_MINUS_CONST       ,
    NODE_TIME_MINUS_FUNTIME     ,
    NODE_TIME_MINUS_VAR         ,
    NODE_FUNTIME_MINUS_CONST    ,
    NODE_FUNTIME_MINUS_TIME     ,
    NODE_FUNTIME_MINUS_FUNTIME  ,
    NODE_FUNTIME_MINUS_VAR      ,
    NODE_VAR_MINUS_CONST        ,
    NODE_VAR_MINUS_TIME         ,
    NODE_VAR_MINUS_FUNTIME      ,
// -------------- UNARY MINUS ---------------------------
    NODE_UNARY_MINUS            ,
    NODE_UNARY_MINUS_CONST      ,
    NODE_UNARY_MINUS_TIME       ,
    NODE_UNARY_MINUS_FUNTIME    ,
// ------------------- MUL ------------------------------
    NODE_MUL                    , // f(x,y,..)*g(x,y,..)
    NODE_MUL_CONST_BY_VAR       , // const*f(x,y,...)
    NODE_MUL_CONST_BY_CONST     , // const1*const2
    NODE_MUL_CONST_BY_TIME      , // const*t
    NODE_MUL_CONST_BY_FUNTIME   , // const*f(t)
    NODE_MUL_TIME_BY_VAR        , // t*f(x,y,...)
    NODE_MUL_TIME_BY_FUNTIME    , // t*f(t)
    NODE_MUL_FUNTIME_BY_VAR     , // f(t)*g(x,y,.....)
    NODE_MUL_FUNTIME_BY_FUNTIME , // f(t)*g(t)
// ------------------- DIV ------------------------------
    NODE_DIV                    , // Division of type const/var cannot be significantly improved.
    NODE_DIV_VAR_BY_CONST       , // Formulae for var/var and const/var differ by only one subtraction.
    NODE_DIV_VAR_BY_TIME        , // The formula depends mainly on the result and the denominator.
    NODE_DIV_VAR_BY_FUNTIME     , // Thus we define special nodes for these cases when denominator is simpler.
    NODE_DIV_TIME_BY_CONST      , // cases TIME_BY_FUNTIME and TIME_BY_VAR are covered by FUNTIME_BY_FUNTIME and FUNTIME_BY_VAR, respectively.
    NODE_DIV_FUNTIME_BY_CONST   ,
    NODE_DIV_FUNTIME_BY_TIME    ,
    NODE_DIV_FUNTIME_BY_FUNTIME ,
    NODE_DIV_CONST_BY_CONST     ,
// --------------- SQUARE AND SQUARE ROOT--------------------
    NODE_SQR,
    NODE_SQR_CONST,
    NODE_SQR_TIME,
    NODE_SQR_FUNTIME,
    NODE_SQRT,
    NODE_SQRT_CONST,
    NODE_SQRT_TIME,
    NODE_SQRT_FUNTIME,
// ------------------- VARIOUS POWERS -----------------------
    NODE_POW,               // general power, exponent can be negative or an interval
    NODE_POW_CONST,
    NODE_POW_TIME,
    NODE_POW_FUNTIME,
    NODE_NATURAL_POW,       // exponent is a natural number
    NODE_HALF_NATURAL_POW,  // exponent is of the form N/2
//  -------------------- EXP LOG ----------------------------
    NODE_EXP,
    NODE_EXP_CONST,
    NODE_EXP_TIME,
    NODE_EXP_FUNTIME,
    NODE_LOG,
    NODE_LOG_CONST,
    NODE_LOG_TIME,
    NODE_LOG_FUNTIME,
//  ------------------- SIN -----------------------------
    NODE_SIN,
    NODE_SIN_CONST,
    NODE_SIN_TIME,
    NODE_SIN_FUNTIME,
// - TODO - NOT IMPLEMENTED
    NODE_ATAN,
    NODE_ACOS,
// ---------------------- VARS, PARAMS, CONST and COS ----------------
    NODE_NULL,
    NODE_CONST,
    NODE_TIME,
    NODE_PARAM,
    NODE_VAR,
    NODE_COS
  };

struct Int4{
  int left, right, result, op;
  Int4(int _left, int _right, int _result, int _op)
    : left(_left), right(_right), result(_result), op(_op)
  {}
};

struct Node : public Int4{
  double val;
  bool isConst;
  bool isTimeDependentOnly;
  Node(int left, int right, int result, int op)
    : Int4(left,right,result,op),
      val(0.0), isConst(false), isTimeDependentOnly(false)
  {}
};

template<class T>
class AbstractNode{
public:
  T* left;
  T* right;
  T* result;
  AbstractNode() : left(0), right(0), result(0){}
  virtual void evalC0(CoeffNo coeffNo) = 0;
  virtual void eval(int degree, int dim, Order order, CoeffNo coeffNo) = 0;
  virtual void evalC0HomogenousPolynomial() = 0;
  virtual void evalHomogenousPolynomial(int degree, int dim, Order order) = 0;
  virtual ~AbstractNode() {}
};

#define CAPD_MAKE_CLASS_NODE(ClassName)\
  template<class T>\
  class ClassName##Node : public AbstractNode<T>\
  { \
    public:\
    void evalC0(CoeffNo coeffNo) {\
      ClassName::evalC0(this->left,this->right,this->result,coeffNo);\
    }\
    void eval(int degree, int dim, Order order, CoeffNo coeffNo) {\
      ClassName::eval(degree,this->left,this->right,this->result,dim,order,coeffNo);\
    }\
    void evalC0HomogenousPolynomial() {\
      ClassName::evalC0HomogenousPolynomial(this->left,this->right,this->result);\
    }\
    void evalHomogenousPolynomial(int degree, int dim, Order order) {\
      ClassName::evalHomogenousPolynomial(degree,this->left,this->right,this->result,dim,order);\
    }\
  }

typedef Int4 MyNode;

}} // namespace capd::autodiff

#endif
