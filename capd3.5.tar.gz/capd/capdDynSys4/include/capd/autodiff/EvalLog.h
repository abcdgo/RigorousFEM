/// @addtogroup autodiff
/// @{

/////////////////////////////////////////////////////////////////////////////
/// @file EvalLog.h
///
/// @author Daniel Wilczak
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) 2000-2012 by the CAPD Group.
//
// This file constitutes a part of the CAPD library,
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.ii.uj.edu.pl/ for details.

#ifndef _CAPD_AUTODIFF_EVAL_LOG_H_
#define _CAPD_AUTODIFF_EVAL_LOG_H_

#include "capd/autodiff/NodeType.h"

namespace capd{
namespace autodiff{

// -------------------- Log ------------------------------------

namespace Log
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    if(coeffNo)
    {
      register T temp = TypeTraits<T>::zero();
      for(int j=1;j<coeffNo;++j)
        temp += T(j) * result[j] * left[coeffNo-j];
      temp /= (T)coeffNo;
      result[coeffNo] = (left[coeffNo] - temp)/(*left);
    }else
      *result = log(*left);
  }

  template<class T>
  inline void evalC1(T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);

    // shift pointers to proper coefficients
    T* resultDer = result + order;
    T* leftDer = left + order;

    for(int derNo=0;derNo<dim;++derNo,resultDer+=order, leftDer+=order)
    {
      register T temp = leftDer[coeffNo];
      for(int j=0;j<coeffNo;++j)
        temp -= resultDer[j] * left[coeffNo-j];
      resultDer[coeffNo] = temp/(*left);
    }
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    switch(degree)
    {
      case 1:
        evalC1(left,right,result,dim,order,coeffNo);
        break;
      case 0:
        evalC0(left,right,result,coeffNo);
        break;
      default:
        throw std::logic_error("Jet propagation of logarithm is not implemented for degree>1");
    }
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = log(*left);
  }

  template<class T>
  inline void evalC1HomogenousPolynomial(T* left, T* right, T* result, int dim, Order order)
  {
    T* resultDer = result + order;
    T* leftDer = left + order;

    for(int derNo=0;derNo<dim;++derNo,resultDer+=order, leftDer+=order)
      *resultDer = (*leftDer) / (*left);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {
    switch(degree)
    {
      case 1:
        evalC1HomogenousPolynomial(left,right,result,dim,order);
        break;
      case 0:
        evalC0HomogenousPolynomial(left,right,result);
        break;
      default:
        throw std::logic_error("Jet propagation of exponent is not implemented for degree>1");
    }
  }
}

namespace LogFunTime
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    Log::evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    Log::evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = log(*left);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}

}

namespace LogTime
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    if(coeffNo)
    {
      register T temp = T(coeffNo-1) * result[coeffNo-1];
      temp /= (T)coeffNo;
      result[coeffNo] = (left[coeffNo] - temp)/(*left);
    }else
      *result = log(*left);
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = log(*left);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}
}


namespace LogConst
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    if(coeffNo)
    {}
    else
      *result = log(*left);
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = log(*left);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}
}

// ----------------------------------------------------------------------------------

//use macro to define classes

CAPD_MAKE_CLASS_NODE(Log);
CAPD_MAKE_CLASS_NODE(LogConst);
CAPD_MAKE_CLASS_NODE(LogTime);
CAPD_MAKE_CLASS_NODE(LogFunTime);

}} // namespace capd::autodiff

#endif
