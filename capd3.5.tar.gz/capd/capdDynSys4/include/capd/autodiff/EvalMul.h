/// @addtogroup autodiff
/// @{

/////////////////////////////////////////////////////////////////////////////
/// @file EvalMul.h
///
/// @author Daniel Wilczak
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) 2000-2012 by the CAPD Group.
//
// This file constitutes a part of the CAPD library,
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.ii.uj.edu.pl/ for details.

#ifndef _CAPD_AUTODIFF_EVAL_MUL_HPP_
#define _CAPD_AUTODIFF_EVAL_MUL_HPP_

#include "capd/autodiff/NodeType.h"

namespace capd{
namespace autodiff{

// -------------------- Mul ------------------------------------

namespace Mul
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    T temp = TypeTraits<T>::zero();
    for(int i=0;i<=coeffNo;++i)
      temp += left[i]* right[coeffNo-i];
    result[coeffNo] = temp;
  }

  template<class T>
  inline void evalC1(T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);

    T* leftDer = left+order;
    T* rightDer = right+order;
    result += (order+coeffNo);
    for(int derNo=0;derNo<dim;++derNo,leftDer+=order,rightDer+=order,result+=order)
    {
      T temp = TypeTraits<T>::zero();
      for(int i=0,j=coeffNo;i<=coeffNo;++i,--j)
        temp += (left[i]*rightDer[j] + leftDer[i]*right[j]);
      *result = temp;
    }
  } // evalC1

  /// hand optimized code for second order jet propagation of multiplication
  template<class T>
  inline void evalC2(T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);

    int s = dim*order;
    // begin of C^1
    T* leftDer = left+order;
    T* rightDer = right+order;
    T* resultDer = result + order + coeffNo;
    // begin of C^2
    T* leftHess = leftDer + s;
    T* rightHess = rightDer + s;
    T* resultHess = resultDer + s;

    for(int derNo=0;derNo<dim;++derNo,leftDer+=order,rightDer+=order,resultDer+=order)
    {
      // case dx^2 and dx
      register T temp = TypeTraits<T>::zero();
      register T temp2 = TypeTraits<T>::zero();
      for(int i=0,j=coeffNo;i<=coeffNo;++i,--j)
      {
        temp += (left[i]*rightHess[j] + leftDer[i]*rightDer[j] + leftHess[i]*right[j]);
        temp2 += (left[i]*rightDer[j] + leftDer[i]*right[j]);
      }
      *resultDer = temp2;
      *resultHess = temp;

      leftHess += order;
      rightHess += order;
      resultHess += order;

      // case dxdy
      T* leftDer2 = leftDer + order;
      T* rightDer2 = rightDer + order;
      for(int derNo2=derNo+1;derNo2<dim;++derNo2,leftDer2+=order,rightDer2+=order,leftHess+=order,rightHess+=order,resultHess+=order)
      {
        temp = TypeTraits<T>::zero();
        for(int i=0,j=coeffNo;i<=coeffNo;++i,--j)
        {
          temp += left[i] * rightHess[j];
          temp += leftDer[i] * rightDer2[j];
          temp += leftDer2[i] * rightDer[j];
          temp += leftHess[i] * right[j];
        }
        *resultHess = temp;
      }
    }
  }  // evalC2

  /// hand optimized code for third order jet propagation of multiplication
  template<class T>
  inline void evalC3(T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC2(left,right,result,dim,order,coeffNo);

    int i1 = order;
    for(int derNo=0;derNo<dim;++derNo,i1+=order)
    {
      int i11 = capd::autodiff::index(dim,derNo,derNo)*order;
      int i111 = capd::autodiff::index(dim,derNo,derNo,derNo)*order;
      T temp = TypeTraits<T>::zero();
      // case dxdxdx
      for(int i=0,j=coeffNo;i<=coeffNo;++i,--j)
      {
        temp += left[i]* right[i111+j];
        temp += left[i1+i] * right[i11+j];
        temp += left[i11+i] * right[i1+j];
        temp += left[i111+i]* right[j];
      }
      result[i111+coeffNo] = temp;

      // cases dxdxdy and dxdydy, assume that x<y
      int i2 = i1+order;
      int i12 = i11+order;
      int i112 = i111 + order;
      for(int derNo2=derNo+1;derNo2<dim;++derNo2,i2+=order,i12+=order,i112+=order)
      {
        int i22 = capd::autodiff::index(dim,derNo2,derNo2)*order;
        int i122 = capd::autodiff::index(dim,derNo,derNo2,derNo2)*order;
        temp = TypeTraits<T>::zero();
        T temp2 = TypeTraits<T>::zero();
        for(int i=0,j=coeffNo;i<=coeffNo;++i,--j)
        {
          temp += left[i]*right[i112+j];    // 0,xxy
          temp += left[i1+i]*right[i12+j];  // x,xy
          temp += left[i2+i]*right[i11+j];  // y,xx
          temp += left[i11+i]*right[i2+j];  // xx,y
          temp += left[i12+i]*right[i1+j];  // xy,x
          temp += left[i112+i]*right[j];    // xxy,0

          temp2 += left[i]*right[i122+j];   // 0,xyy
          temp2 += left[i1+i]*right[i22+j]; // x,yy
          temp2 += left[i2+i]*right[i12+j]; // y,xy
          temp2 += left[i12+i]*right[i2+j]; // xy,y
          temp2 += left[i22+i]*right[i1+j]; // yy,x
          temp2 += left[i122+i]*right[j];   // xyy,0
        }
        result[i112+coeffNo] = temp;
        result[i122+coeffNo] = temp2;

        // case dxdydz, assume x<y<z
        int i3 = i2+order;
        int i123 = i122+order;
        int i23 = i22 + order;
        int i13 = i12 + order;
        for(int derNo3=derNo2+1;derNo3<dim;++derNo3,i3+=order,i123+=order,i23+=order,i13+=order)
        {
          temp = TypeTraits<T>::zero();
          for(int i=0,j=coeffNo;i<=coeffNo;++i,--j)
          {
            temp += left[i] * right[i123+j];    // 0,xyz
            temp += left[i1+i] * right[i23+j];  // x,yz
            temp += left[i2+i] * right[i13+j];  // y,xz
            temp += left[i3+i] * right[i12+j];  // z,xy
            temp += left[i12+i] * right[i3+j];  // xy,z
            temp += left[i13+i] * right[i2+j];  // xz,y
            temp += left[i23+i]*right[i1+j];    // yz,x
            temp += left[i123+i]*right[j];      // xyz,0
          }
          result[i123+coeffNo] = temp;
        }
      }
    }
  }  // evalC3


  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    switch(degree)
    {
      case 3:
        evalC3(left,right,result,dim,order,coeffNo);
        break;
      case 2:
        evalC2(left,right,result,dim,order,coeffNo);
        break;
      case 1:
        evalC1(left,right,result,dim,order,coeffNo);
        break;
      case 0:
        evalC0(left,right,result,coeffNo);
        break;
      default:
        throw std::logic_error("Jet propagation of multiplication is not implemented for degree>3");
    }
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    (*result) = (*left)*(*right);
  }

  template<class T>
  inline void evalC1HomogenousPolynomial(T* left, T* right, T* result, int dim, Order order)
  {
    T* leftDer = left + order;
    T* rightDer = right + order;
    T* resultDer = result + order;
    for(int derNo=0;derNo<dim;++derNo,leftDer+=order,rightDer+=order,resultDer+=order)
      *resultDer = (*left)*(*rightDer) + (*leftDer) *(*right);
  }

  template<class T>
  inline void evalC2HomogenousPolynomial(T* left, T* right, T* result, int dim, Order order)
  {
    T* leftDer = left + order;
    T* rightDer = right + order;
    T* resultDer = result + order;
    int s = dim*order;
    T* leftHess = leftDer + s;
    T* rightHess = rightDer + s;
    T* resultHess = resultDer + s;

    for(int derNo=0;derNo<dim;++derNo,leftDer+=order,rightDer+=order,resultDer+=order)
    {
      // case dxdx
      *resultHess  = (*left)     * (*rightHess)
                   + (*leftDer)  * (*rightDer)
                   + (*leftHess) * (*right);

      // case dxdy
      resultHess +=order;
      leftHess += order;
      rightHess += order;
      T* leftDer2 = leftDer + order;
      T* rightDer2 = rightDer + order;
      for(int derNo2=derNo+1;derNo2<dim;++derNo2,resultHess+=order,leftHess+=order,rightHess+=order,leftDer2+=order,rightDer2+=order)
      {
        *resultHess  = (*left)     * (*rightHess)
                     + (*leftDer2) * (*rightDer)
                     + (*leftDer)  * (*rightDer2)
                     + (*leftHess) * (*right);
      }
    }
  }

  template<class T>
  inline void evalC3HomogenousPolynomial(T* left, T* right, T* result, int dim, Order order)
  {
    int i1 = order;
    for(int derNo=0;derNo<dim;++derNo,i1+=order)
    {
      int i11 = capd::autodiff::index(dim,derNo,derNo)*order;
      int i111 = capd::autodiff::index(dim,derNo,derNo,derNo)*order;
      result[i111] = (*left)*right[i111] + left[i1]*right[i11] + left[i11]*right[i1] + left[i111]*(*right);

      // cases dxdxdy and dxdydy, assume that x<y
      int i2 = i1+order;
      int i12 = i11+order;
      int i112 = i111 + order;
      for(int derNo2=derNo+1;derNo2<dim;++derNo2,i2+=order,i12+=order,i112+=order)
      {
        int i22 = capd::autodiff::index(dim,derNo2,derNo2)*order;
        int i122 = capd::autodiff::index(dim,derNo,derNo2,derNo2)*order;
        result[i112] = (*left)*right[i112] + left[i1]*right[i12] + left[i2]*right[i11] + left[i11]*right[i2] + left[i12]*right[i1] + left[i112]*(*right);
        result[i122] = (*left)*right[i122] + left[i1]*right[i22] + left[i2]*right[i12] + left[i12]*right[i2] + left[i22]*right[i1] + left[i122]*(*right);

        // case dxdydz, assume x<y<z
        int i3 = i2+order;
        int i123 = i122+order;
        int i23 = i22 + order;
        int i13 = i12 + order;
        for(int derNo3=derNo2+1;derNo3<dim;++derNo3,i3+=order,i123+=order,i23+=order,i13+=order)

          result[i123]
              = (*left)    * right[i123]
              + left[i1]   * right[i23]
              + left[i2]   * right[i13]
              + left[i3]   * right[i12]
              + left[i12]  * right[i3]
              + left[i13]  * right[i2]
              + left[i23]  * right[i1]
              + left[i123] * (*right);

      }
    }
  }  // evalC3

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {
    switch(degree)
    {
      case 3:
        evalC3HomogenousPolynomial(left,right,result,dim,order);
        break;
      case 2:
        evalC2HomogenousPolynomial(left,right,result,dim,order);
        break;
      case 1:
        evalC1HomogenousPolynomial(left,right,result,dim,order);
        break;
      case 0:
        evalC0HomogenousPolynomial(left,right,result);
        break;
      default:
        throw std::logic_error("Jet propagation of multiplication is not implemented for degree>3");
    }
  }
}

// -------------------- MulConstByVar -------------------------------

namespace MulConstByVar
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    result[coeffNo] = (*left) * right[coeffNo];
  }

  template<class T>
  inline void evalC1(T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    right+= coeffNo;
    result+= coeffNo;
    for(int derNo=0;derNo<=dim;++derNo,right+=order,result+=order)
      *result = (*left) * (*right);
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC1(left,right,result,newton(dim+degree,dim)-1,order,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = (*left) * (*right);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {

    int s = newton(dim+degree-1,dim)*order;
    right += s;
    result += s;
    for(int derNo=0;derNo<newton(dim-1+degree,degree);++derNo,right+=order,result+=order)
      *result = (*left) * (*right);
  }
}

// -------------------- MulConstByConst -------------------------------

namespace MulConstByConst
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    if(coeffNo==0)
      *result = (*left) * (*right);
  }


  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = (*left) * (*right);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}
}

// -------------------- MulConstByFunTime -------------------------------

namespace MulConstByFunTime
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    result[coeffNo] = (*left) * right[coeffNo];
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = (*left) * (*right);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}
}

// -------------------- MulConstByTime -------------------------------

namespace MulConstByTime
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    switch(coeffNo)
    {
      case 0:
        *result = (*left) * (*right); break;
      case 1:
        result[1] = *left;
    }
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = (*left) * (*right);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}
}

// -------------------- MulTimeByVar -------------------------------

namespace MulTimeByVar
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    switch(coeffNo)
    {
    case 0:
      *result = (*left) * (*right);
      break;
    default:
      result[coeffNo] = (*left) * right[coeffNo] + right[coeffNo-1];
    }
  }

  template<class T>
  inline void evalC1(T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    switch(coeffNo)
    {
    case 0:
      for(int i=0;i<=dim;++i,result+=order,right+=order)
        *result = (*left) * (*right);
      break;
    default:
      result+= coeffNo;
      right += coeffNo;
      for(int i=0;i<=dim;++i,result+=order,right+=order)
        *result = (*left) * (*right) + *(right-1);
    }
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC1(left,right,result,newton(dim+degree,degree)-1,order,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = (*left) * (*right);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {
    MulConstByVar::evalHomogenousPolynomial(degree,left,right,result,dim,order);
  }
}

// -------------------- MulTimeByFunTime -------------------------------

namespace MulTimeByFunTime
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    MulTimeByVar::evalC0(left,right,result,coeffNo);
  }


  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    MulTimeByVar::evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = (*left) * (*right);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}
}


// -------------------- MulFunTimeByVar -------------------------------

namespace MulFunTimeByVar
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    Mul::evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC1(T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    result+= coeffNo;
    for(int derNo=0;derNo<=dim;++derNo,result+=order,right+=order)
    {
      register T temp = TypeTraits<T>::zero();
      for(int i=0,j=coeffNo;i<coeffNo;++i,--j)
        temp += left[i]* right[j];
      *result = temp;
    }
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC1(left,right,result,newton(dim+degree,degree)-1,order,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = (*left) * (*right);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {
    MulConstByVar::evalHomogenousPolynomial(degree,left,right,result,dim,order);
  }
}

// -------------------- MulFunTimeByFunTime -------------------------------

namespace MulFunTimeByFunTime
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    Mul::evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    Mul::evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = (*left) * (*right);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}
}

// ----------------------------------------------------------------------------------

//use macro to define classes

CAPD_MAKE_CLASS_NODE(Mul);
CAPD_MAKE_CLASS_NODE(MulConstByVar);
CAPD_MAKE_CLASS_NODE(MulConstByConst);
CAPD_MAKE_CLASS_NODE(MulConstByTime);
CAPD_MAKE_CLASS_NODE(MulConstByFunTime);
CAPD_MAKE_CLASS_NODE(MulTimeByVar);
CAPD_MAKE_CLASS_NODE(MulTimeByFunTime);
CAPD_MAKE_CLASS_NODE(MulFunTimeByVar);
CAPD_MAKE_CLASS_NODE(MulFunTimeByFunTime);

}} // namespace capd::autodiff

#endif
