/// @addtogroup autodiff
/// @{

/////////////////////////////////////////////////////////////////////////////
/// @file EvalSqr.h
///
/// @author Daniel Wilczak
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) 2000-2012 by the CAPD Group.
//
// This file constitutes a part of the CAPD library,
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.ii.uj.edu.pl/ for details.

#ifndef _CAPD_AUTODIFF_EVAL_SQR_H_
#define _CAPD_AUTODIFF_EVAL_SQR_H_

namespace capd{
namespace autodiff{

// -------------------- Sqr ------------------------------------

namespace Sqr{

  template<class T>
  inline T sqrProduct(T* x, int n)
  {
    register T temp = TypeTraits<T>::zero();
    int p = n/2;
    for(int j=0;j<p;++j)
      temp += x[j] * x[n-j];

    return (n%2)
              ? 2.*(temp + x[p]*x[p+1])
              : 2.*temp + sqr(x[p]);

  }

  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    if(coeffNo)
        result[coeffNo] = sqrProduct(left,coeffNo);
    else
      *result = sqr(*left);
  }

  template<class T>
  inline void evalC1(T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);
    T* leftDer = left+order;
    result += order+coeffNo;
    for(int derNo=0;derNo<dim;++derNo,leftDer+=order,result+=order)
    {
      register T temp = TypeTraits<T>::zero();
      for(int i=0;i<=coeffNo;++i)
        temp += left[i] * leftDer[coeffNo-i];
      *result = 2.*temp;
    }
  }


  template<class T>
  inline void evalC2(T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);

    int s = dim*order;
    // begin of C^1
    T* leftDer = left+order;
    T* resultDer = result + order + coeffNo;
    // begin of C^2
    T* leftHess = leftDer + s;
    T* resultHess = resultDer + s;

    for(int derNo=0;derNo<dim;++derNo,leftDer+=order,resultDer+=order)
    {
      // case dx^2 and dx
      register T temp = TypeTraits<T>::zero();
      register T temp2 = TypeTraits<T>::zero();
      for(int i=0,j=coeffNo;i<=coeffNo;++i,--j)
      {
        temp += left[i]*leftHess[j];
        temp2 += left[i]*leftDer[j];
      }
      *resultDer = 2.*temp2;
      *resultHess = 2.*temp + sqrProduct(leftDer,coeffNo);

      leftHess += order;
      resultHess += order;

      // case dxdy
      T* leftDer2 = leftDer + order;
      for(int derNo2=derNo+1;derNo2<dim;++derNo2,leftDer2+=order,leftHess+=order,resultHess+=order)
      {
        temp = TypeTraits<T>::zero();
        for(int i=0,j=coeffNo;i<=coeffNo;++i,--j)
        {
          temp += left[i] * leftHess[j];
          temp += leftDer[i] * leftDer2[j];
        }
        *resultHess = 2.*temp;
      }
    }
  }


  template<class T>
  inline void evalC3(T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC2(left,right,result,dim,order,coeffNo);
    int i1 = order;
    for(int derNo=0;derNo<dim;++derNo,i1+=order)
    {
      int i11 = capd::autodiff::index(dim,derNo,derNo)*order;
      int i111 = capd::autodiff::index(dim,derNo,derNo,derNo)*order;
      T temp = TypeTraits<T>::zero();
      // case dxdxdx
      for(int i=0,j=coeffNo;i<=coeffNo;++i,--j)
      {
        temp += left[i]* left[i111+j];
        temp += left[i1+i] * left[i11+j];
      }
      result[i111+coeffNo] = 2.*temp;

      // cases dxdxdy and dxdydy, assume that x<y
      int i2 = i1+order;
      int i12 = i11+order;
      int i112 = i111 + order;
      for(int derNo2=derNo+1;derNo2<dim;++derNo2,i2+=order,i12+=order,i112+=order)
      {
        int i22 = capd::autodiff::index(dim,derNo2,derNo2)*order;
        int i122 = capd::autodiff::index(dim,derNo,derNo2,derNo2)*order;
        temp = TypeTraits<T>::zero();
        T temp2 = TypeTraits<T>::zero();
        for(int i=0,j=coeffNo;i<=coeffNo;++i,--j)
        {
          temp += left[i]*left[i112+j];    // 0,xxy
          temp += left[i1+i]*left[i12+j];  // x,xy
          temp += left[i2+i]*left[i11+j];  // y,xx

          temp2 += left[i]*left[i122+j];   // 0,xyy
          temp2 += left[i1+i]*left[i22+j]; // x,yy
          temp2 += left[i2+i]*left[i12+j]; // y,xy
        }
        result[i112+coeffNo] = 2.*temp;
        result[i122+coeffNo] = 2.*temp2;

        // case dxdydz, assume x<y<z
        int i3 = i2+order;
        int i123 = i122+order;
        int i23 = i22 + order;
        int i13 = i12 + order;
        for(int derNo3=derNo2+1;derNo3<dim;++derNo3,i3+=order,i123+=order,i23+=order,i13+=order)
        {
          temp = TypeTraits<T>::zero();
          for(int i=0,j=coeffNo;i<=coeffNo;++i,--j)
          {
            temp += left[i] * left[i123+j];    // 0,xyz
            temp += left[i1+i] * left[i23+j];  // x,yz
            temp += left[i2+i] * left[i13+j];  // y,xz
            temp += left[i3+i] * left[i12+j];  // z,xy
          }
          result[i123+coeffNo] = 2.*temp;
        }
      }
    }
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    switch(degree)
    {
      case 3:
        evalC3(left,right,result,dim,order,coeffNo);
        break;
      case 2:
        evalC2(left,right,result,dim,order,coeffNo);
        break;
      case 1:
        evalC1(left,right,result,dim,order,coeffNo);
        break;
      case 0:
        evalC0(left,right,result,coeffNo);
        break;
      default:
        throw std::logic_error("Jet propagation of Sqr is not implemented for degree>3");
    }
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    (*result) = sqr(*left);
  }

  template<class T>
  inline void evalC1HomogenousPolynomial(T* left, T* right, T* result, int dim, Order order)
  {
    T* leftDer = left + order;
    T* resultDer = result + order;
    for(int derNo=0;derNo<dim;++derNo,leftDer+=order,resultDer+=order)
      *resultDer = 2.*(*left)*(*leftDer);
  }

  template<class T>
  inline void evalC2HomogenousPolynomial(T* left, T* right, T* result, int dim, Order order)
  {
    T* leftDer = left + order;
    T* resultDer = result + order;
    int s = dim*order;
    T* leftHess = leftDer + s;
    T* resultHess = resultDer + s;

    for(int derNo=0;derNo<dim;++derNo,leftDer+=order,resultDer+=order)
    {
      // case dxdx
      *resultHess  = 2.*(*left)*(*leftHess) + sqr(*leftDer);

      // case dxdy
      resultHess +=order;
      leftHess += order;
      T* leftDer2 = leftDer + order;
      for(int derNo2=derNo+1;derNo2<dim;++derNo2,resultHess+=order,leftHess+=order,leftDer2+=order)
        *resultHess  = 2.*( (*left)*(*leftHess)  +  (*leftDer)*(*leftDer2));
    }
  }

  template<class T>
  inline void evalC3HomogenousPolynomial(T* left, T* right, T* result, int dim, Order order)
  {
    int i1 = order;
    for(int derNo=0;derNo<dim;++derNo,i1+=order)
    {
      int i11 = capd::autodiff::index(dim,derNo,derNo)*order;
      int i111 = capd::autodiff::index(dim,derNo,derNo,derNo)*order;

      // case dxdxdx
      result[i111]= 2.*(*left* left[i111] + left[i1]*left[i11]);

      // cases dxdxdy and dxdydy, assume that x<y
      int i2 = i1+order;
      int i12 = i11+order;
      int i112 = i111+order;
      for(int derNo2=derNo+1;derNo2<dim;++derNo2,i2+=order,i12+=order,i112+=order)
      {
        int i22 = capd::autodiff::index(dim,derNo2,derNo2)*order;
        int i122 = capd::autodiff::index(dim,derNo,derNo2,derNo2)*order;
        result[i112] = 2.*(*left*left[i112] + left[i1]*left[i12] + left[i2]*left[i11]);
        result[i122] = 2.*(*left*left[i122] + left[i1]*left[i22] + left[i2]*left[i12]);

        // case dxdydz, assume x<y<z
        int i3 = i2+order;
        int i123 = i122+order;
        int i23 = i22 + order;
        int i13 = i12 + order;
        for(int derNo3=derNo2+1;derNo3<dim;++derNo3,i3+=order,i123+=order,i23+=order,i13+=order)
          result[i123] = 2.*(*left*left[i123] + left[i1]*left[i23] + left[i2]*left[i13] + left[i3]*left[i12]);
      }
    }
  }  // evalC3

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {
    switch(degree)
    {
      case 3:
        evalC3HomogenousPolynomial(left,right,result,dim,order);
        break;
      case 2:
        evalC2HomogenousPolynomial(left,right,result,dim,order);
        break;
      case 1:
        evalC1HomogenousPolynomial(left,right,result,dim,order);
        break;
      case 0:
        evalC0HomogenousPolynomial(left,right,result);
        break;
      default:
        throw std::logic_error("Jet propagation of multiplication is not implemented for degree>3");
    }
  }

}

// -------------------- SqrFunTime ------------------------------------

namespace SqrFunTime
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    Sqr::evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    Sqr::evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = sqr(*left);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}

}

// -------------------- SqrTime ------------------------------------

namespace SqrTime
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    if(coeffNo==1)
      result[1] = 2.;
    else if(coeffNo==0)
      *result = sqr(*left);
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = sqr(*left);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}
}

// -------------------- SqrConst ------------------------------------

namespace SqrConst
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    if(coeffNo)
    {}
    else
      *result = sqr(*left);
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = sqr(*left);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}
}

// ----------------------------------------------------------------------------------

//use macro to define classes

CAPD_MAKE_CLASS_NODE(Sqr);
CAPD_MAKE_CLASS_NODE(SqrTime);
CAPD_MAKE_CLASS_NODE(SqrFunTime);
CAPD_MAKE_CLASS_NODE(SqrConst);

}} // namespace capd::autodiff

#endif
