/// @addtogroup autodiff
/// @{

/////////////////////////////////////////////////////////////////////////////
/// @file EvalNaturalPow.h
///
/// @author Daniel Wilczak
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) 2000-2012 by the CAPD Group.
//
// This file constitutes a part of the CAPD library,
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.ii.uj.edu.pl/ for details.

#ifndef _CAPD_AUTODIFF_EVAL_NATURALPOW_H_
#define _CAPD_AUTODIFF_EVAL_NATURALPOW_H_

namespace capd{
namespace autodiff{

// -------------------- NaturalPow ------------------------------------

namespace NaturalPow
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    T c = *right;
    T u = *left;
    if(coeffNo)
    {
      register T temp = capd::TypeTraits<T>::zero();
      for(int j=0;j<coeffNo;++j)
        temp += (c*((int)coeffNo-j)-j) * result[j] *left[coeffNo-j];
      result[coeffNo] = temp/((double)coeffNo * u);
    }
    else
      *result = exp(c * log(u));
  }

  template<class T>
  inline void evalC1(T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);

    T* leftDer = left + order;
    T* resultDer = result + order;
    for(int derNo=0;derNo<dim;++derNo,leftDer+=order,resultDer+=order)
    {
      register T temp1 = result[coeffNo] * (*leftDer);
      register T temp2 = capd::TypeTraits<T>::zero();
      for(int j=0;j<coeffNo;++j)
      {
        temp1 += result[j] * leftDer[coeffNo-j];
        temp2 += left[coeffNo-j] * resultDer[j];
      }
      resultDer[coeffNo] = (temp1*(*right)-temp2)/(*left);
    }
  } // evalC1

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    switch(degree)
    {
      case 1:
        evalC1(left,right,result,dim,order,coeffNo);
        break;
      case 0:
        evalC0(left,right,result,coeffNo);
        break;
      default:
        throw std::logic_error("Jet propagation of Power is not implemented for degree>1");
    }
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = exp((*right) * log(*left));
  }

  template<class T>
  inline void evalC1HomogenousPolynomial(T* left, T* right, T* result, int dim, Order order)
  {
    T* leftDer = left + order;
    T* resultDer = result + order;
    T t = (*result)*(*right)/(*left);
    for(int derNo=0;derNo<dim;++derNo,leftDer+=order,resultDer+=order)
    {
      *resultDer = t*(*leftDer);
    }
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {
    switch(degree)
    {
      case 1:
        evalC1HomogenousPolynomial(left,right,result,dim,order);
        break;
      case 0:
        evalC0HomogenousPolynomial(left,right,result);
        break;
      default:
        throw std::logic_error("Jet propagation of Power is not implemented for degree>1");
    }
  }
}

// -------------------- NaturalPow ------------------------------------

/**
 * Auxiliary function.
 * Computes d^i x^c where c is integer, i>0 and x can be zero
 * @param x - array of coefficients of coefficient
 */

template<class ScalarT>
inline
ScalarT* evalC0SingularNaturalPow(CoeffNo coeffNo, const ScalarT* x, ScalarT* temp1, ScalarT* temp2, int c)
{
  for(int i=1;i<c;++i)
  {
    for(int p=0;p<=coeffNo;++p)
    {
      temp2[p] = TypeTraits<ScalarT>::zero();
      for(int j=0;j<=p;++j)
        temp2[p] += x[j]*temp1[p-j];
    }
    std::swap(temp1,temp2);
  }
  return temp1;
}

template<int D>
struct NaturalPow;

template<>
struct NaturalPow<0>
{
  template<class ScalarT>
  static inline void eval(int degree, VarNo l, VarNo r, VarNo k, int dim, Order order, CoeffNo coeffNo, JetSize jetSize, ScalarT* data)
  {
    int c = toInt(leftBound(getC0Coeff(data,r,jetSize,CoeffNo(0))));
    ScalarT* u = &getC0Coeff(data,l,jetSize,CoeffNo(0));
    if(coeffNo)
    {
      if(!(isSingular(*u)))
      {
        ScalarT temp = capd::TypeTraits<ScalarT>::zero();
        for(int j=0;j<coeffNo;++j)
          temp += (c*((int)coeffNo-j)-j) * getC0Coeff(data,k,jetSize,CoeffNo(j)) * getC0Coeff(data,l,jetSize,CoeffNo(coeffNo-j));
        getC0Coeff(data,k,jetSize,coeffNo) = temp/((double)coeffNo * u[0]);
      }
      else
      {
        ScalarT* t = new ScalarT[2*(coeffNo+1)];
        std::copy(u,u+coeffNo+1,t);
        ScalarT* p = evalC0SingularNaturalPow(coeffNo,u,t,t+coeffNo+1,c-1);

        ScalarT temp = capd::TypeTraits<ScalarT>::zero();
        for(int i=0;i<=coeffNo;++i)
          temp += u[i]*p[coeffNo-i];
        getC0Coeff(data,k,jetSize,coeffNo) = temp;
        delete[]t;
      }
    }
    else
      getC0Coeff(data,k,jetSize,coeffNo) = power(*u,c);
  }
};

template<>
struct NaturalPow<1>
{
  template<class ScalarT>
  static inline void eval(int degree, VarNo l, VarNo r, VarNo k, int dim, Order order, CoeffNo coeffNo, JetSize jetSize, ScalarT* data)
  {
    int c = toInt(leftBound(getC0Coeff(data,r,jetSize,CoeffNo(0))));
    ScalarT* u = &getC0Coeff(data,l,jetSize,CoeffNo(0));
    if(coeffNo)
    {
      if(!(isSingular(*u))) // d^i x^m where i>0 and x!=0
      {
        // C^0 part
        ScalarT temp = capd::TypeTraits<ScalarT>::zero();
        for(int j=0;j<coeffNo;++j)
          temp += (c*((int)coeffNo-j)-j) * getC0Coeff(data,k,jetSize,CoeffNo(j)) * getC0Coeff(data,l,jetSize,CoeffNo(coeffNo-j));
        getC0Coeff(data,k,jetSize,coeffNo) = temp/((double)coeffNo * u[0]);

        // C^1 part
        for(int derNo=0;derNo<dim;++derNo)
        {
          ScalarT temp1 = getC0Coeff(data,k,jetSize,coeffNo) * getC1Coeff(data,l,DerNo(derNo),jetSize,order,CoeffNo(0));
          ScalarT temp2 = capd::TypeTraits<ScalarT>::zero();
          for(int j=0;j<coeffNo;++j)
          {
            temp1 += getC0Coeff(data,k,jetSize,CoeffNo(j)) * getC1Coeff(data,l,DerNo(derNo),jetSize,order,CoeffNo(coeffNo-j));
            temp2 += getC0Coeff(data,l,jetSize,CoeffNo(coeffNo-j)) * getC1Coeff(data,k,DerNo(derNo),jetSize,order,CoeffNo(j));
          }
          getC1Coeff(data,k,DerNo(derNo),jetSize,order,coeffNo) = (temp1*getC0Coeff(data,r,jetSize,CoeffNo(0))-temp2)/u[0];
        }
      }
      else // d^i x^m where i>0 and x is singular. Recompute coefficients from nonrecursive formula
      {
        ScalarT* t = new ScalarT[2*(coeffNo+1)];
        std::copy(u,u+coeffNo+1,t);
        ScalarT* p = evalC0SingularNaturalPow(coeffNo,u,t,t+coeffNo+1,c-1);

        ScalarT temp = capd::TypeTraits<ScalarT>::zero();
        for(int i=0;i<=coeffNo;++i)
          temp += u[i]*p[coeffNo-i];
        getC0Coeff(data,k,jetSize,coeffNo) = temp;

        for(int derNo=0;derNo<dim;++derNo)
        {
          temp = capd::TypeTraits<ScalarT>::zero();
          for(int j=0;j<=coeffNo;++j)
            temp += p[j] * getC1Coeff(data,l,DerNo(derNo),jetSize,order,CoeffNo(coeffNo-j));
          getC1Coeff(data,k,DerNo(derNo),jetSize,order,coeffNo) = ((double)c)*temp;
        }
        delete[]t;
      }
    }
    else
    {
      ScalarT temp = power(*u,c-1);
      getC0Coeff(data,k,jetSize,coeffNo) = (*u)*temp;
      temp *= c;
      for(int derNo=0;derNo<dim;++derNo)
        getC1Coeff(data,k,DerNo(derNo),jetSize,order,coeffNo) = temp*getC1Coeff(data,l,DerNo(derNo),jetSize,order,CoeffNo(0));
    }
  }
};

template<int D>
struct NaturalPow{
  template<class ScalarT>
  static inline void eval(int degree, VarNo l, VarNo r, VarNo k, int dim, Order order, CoeffNo coeffNo, JetSize jetSize, ScalarT* data)
  {
    switch(degree)
    {
      case 1:
        NaturalPow<1>::eval(degree,l,r,k,dim,order,coeffNo,jetSize,data);
        break;
      case 0:
        NaturalPow<0>::eval(degree,l,r,k,dim,order,coeffNo,jetSize,data);
        break;
      default:
        throw std::logic_error("Jet propagation of natural power is not implemented for degree>1");
    }
  }
};

// -------------------- HalfNaturalPow ------------------------------------

template<int D>
struct HalfNaturalPow;

template<>
struct HalfNaturalPow<0>
{
  template<class ScalarT>
  static inline void eval(int degree, VarNo l, VarNo r, VarNo k, int dim, Order order, CoeffNo coeffNo, JetSize jetSize, ScalarT* data)
  {
    ScalarT c = getC0Coeff(data,r,jetSize,CoeffNo(0));
    ScalarT u = getC0Coeff(data,l,jetSize,CoeffNo(0));
    if(coeffNo)
    {
      ScalarT temp = capd::TypeTraits<ScalarT>::zero();
      for(int j=0;j<coeffNo;++j)
        temp += (c*((int)coeffNo-j)-j) * getC0Coeff(data,k,jetSize,CoeffNo(j)) * getC0Coeff(data,l,jetSize,CoeffNo(coeffNo-j));
      getC0Coeff(data,k,jetSize,coeffNo) = temp/((double)coeffNo * u);
    }
    else
    {
      int c2 = toInt(leftBound(2*c));
      getC0Coeff(data,k,jetSize,CoeffNo(0)) = power(sqrt(u),c2);
    }
  }
};

template<>
struct HalfNaturalPow<1>
{
  template<class ScalarT>
  static inline void eval(int degree, VarNo l, VarNo r, VarNo k, int dim, Order order, CoeffNo coeffNo, JetSize jetSize, ScalarT* data)
  {
    HalfNaturalPow<0>::eval(degree,l,r,k,dim,order,coeffNo,jetSize,data);
    for(int derNo=0;derNo<dim;++derNo)
    {
      ScalarT temp1 = getC0Coeff(data,k,jetSize,coeffNo) * getC1Coeff(data,l,DerNo(derNo),jetSize,order,CoeffNo(0));
      ScalarT temp2 = capd::TypeTraits<ScalarT>::zero();
      for(int j=0;j<coeffNo;++j)
      {
        temp1 += getC0Coeff(data,k,jetSize,CoeffNo(j)) * getC1Coeff(data,l,DerNo(derNo),jetSize,order,CoeffNo(coeffNo-j));
        temp2 += getC0Coeff(data,l,jetSize,CoeffNo(coeffNo-j)) * getC1Coeff(data,k,DerNo(derNo),jetSize,order,CoeffNo(j));
      }
      getC1Coeff(data,k,DerNo(derNo),jetSize,order,coeffNo) = (temp1*getC0Coeff(data,r,jetSize,CoeffNo(0))-temp2)/getC0Coeff(data,l,jetSize,CoeffNo(0));
    }
  }
};

template<int D>
struct HalfNaturalPow{
  template<class ScalarT>
  static inline void eval(int degree, VarNo l, VarNo r, VarNo k, int dim, Order order, CoeffNo coeffNo, JetSize jetSize, ScalarT* data)
  {
    switch(degree)
    {
      case 1:
        HalfNaturalPow<1>::eval(degree,l,r,k,dim,order,coeffNo,jetSize,data);
        break;
      case 0:
        HalfNaturalPow<0>::eval(degree,l,r,k,dim,order,coeffNo,jetSize,data);
        break;
      default:
        throw std::logic_error("Jet propagation of power to (n+1)/2 is not implemented for degree>1");
    }
  }
};

}} // namespace capd::autodiff

#endif
