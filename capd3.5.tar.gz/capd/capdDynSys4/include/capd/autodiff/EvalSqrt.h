/// @addtogroup autodiff
/// @{

/////////////////////////////////////////////////////////////////////////////
/// @file EvalSqrt.h
///
/// @author Daniel Wilczak
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) 2000-2012 by the CAPD Group.
//
// This file constitutes a part of the CAPD library,
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.ii.uj.edu.pl/ for details.

#ifndef _CAPD_AUTODIFF_EVAL_SQRT_H_
#define _CAPD_AUTODIFF_EVAL_SQRT_H_

#include "capd/autodiff/NodeType.h"

namespace capd{
namespace autodiff{

// -------------------- Sqrt ------------------------------------

namespace Sqrt
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    if(coeffNo)
    {
      register T temp = capd::TypeTraits<T>::zero();
      for(int j=0;j<coeffNo;++j)
        temp += 0.5*((int)coeffNo-3*j) * result[j] * left[coeffNo-j];
      result[coeffNo] = temp/((double)coeffNo * (*left));
    }else
      *result = sqrt(*left);
  }

  template<class T>
  inline void evalC1(T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);
    T* leftDer = left+order;
    T* resultDer = result+order;
    T t = 0.5*result[coeffNo]/(*left);

    for(int derNo=0;derNo<dim;++derNo,leftDer+=order,resultDer+=order)
    {
      register T temp = t * (*leftDer);
      for(int j=0;j<coeffNo;++j)
      {
        temp += 0.5* result[j] * leftDer[coeffNo-j];
        temp -= left[coeffNo-j]* resultDer[j];
      }
      resultDer[coeffNo] = temp;
    }
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    switch(degree)
    {
      case 1:
        evalC1(left,right,result,dim,order,coeffNo);
        break;
      case 0:
        evalC0(left,right,result,coeffNo);
        break;
      default:
        throw std::logic_error("Jet propagation of Sqrt is not implemented for degree>1");
    }
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = sqrt(*left);
  }

  template<class T>
  inline void evalC1HomogenousPolynomial(T* left, T* right, T* result, int dim, Order order)
  {
    T* leftDer = left+order;
    T* resultDer = result+order;
    T temp = 0.5*(*result)/(*left);
    for(int derNo=0;derNo<dim;++derNo,leftDer+=order,resultDer+=order)
      *resultDer =  temp * (*leftDer);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {
    switch(degree)
    {
      case 1:
        evalC1HomogenousPolynomial(left,right,result,dim,order);
        break;
      case 0:
        evalC0HomogenousPolynomial(left,right,result);
        break;
      default:
        throw std::logic_error("Jet propagation of Sqrt is not implemented for degree>1");
    }
  }

}

// -------------------- SqrtFunTime ------------------------------------

namespace SqrtFunTime
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    Sqrt::evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    Sqrt::evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = sqrt(*left);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}

}

// -------------------- SqrtTime ------------------------------------

namespace SqrtTime
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    if(coeffNo)
      result[coeffNo] = (1.5-coeffNo) * result[coeffNo-1]/((double)coeffNo * (*left));
    else
      *result = sqrt(*left);
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = sqrt(*left);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}

}

// -------------------- SqrtConst ------------------------------------

namespace SqrtConst
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    *result = sqrt(*left);
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    *result = sqrt(*left);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = sqrt(*left);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}

}

// ----------------------------------------------------------------------------------

//use macro to define classes

CAPD_MAKE_CLASS_NODE(Sqrt);
CAPD_MAKE_CLASS_NODE(SqrtConst);
CAPD_MAKE_CLASS_NODE(SqrtTime);
CAPD_MAKE_CLASS_NODE(SqrtFunTime);

}} // namespace capd::autodiff

#endif
