/// @addtogroup autodiff
/// @{

/////////////////////////////////////////////////////////////////////////////
/// @file EvalSinCos.h
///
/// @author Daniel Wilczak
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) 2000-2012 by the CAPD Group.
//
// This file constitutes a part of the CAPD library,
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.ii.uj.edu.pl/ for details.

#ifndef _CAPD_AUTODIFF_EVAL_SIN_COS_H_
#define _CAPD_AUTODIFF_EVAL_SIN_COS_H_

#include "capd/autodiff/NodeType.h"

namespace capd{
namespace autodiff{

// -------------------- Sin ------------------------------------

namespace Sin
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    if(coeffNo)
    {
      register T tempSin = capd::TypeTraits<T>::zero();
      register T tempCos = capd::TypeTraits<T>::zero();
      for(int j=1;j<=coeffNo;++j)
      {
        tempSin += double(j) * right[coeffNo-j] * left[j];
        tempCos -= double(j) * result[coeffNo-j] * left[j];
      }
      result[coeffNo] = tempSin/(double)coeffNo;
      right[coeffNo] = tempCos/(double)coeffNo;
    }
    else
    {
      (*result) = sin(*left);
      (*right) = cos(*left);
    }
  }


  template<class T>
  inline void evalC1(T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);

    T* leftDer = left+order;
    T* rightDer = right+order+coeffNo;
    T* resultDer = result+order+coeffNo;
    for(int derNo=0;derNo<dim;++derNo,leftDer+=order,rightDer+=order,resultDer+=order)
    {
      register T tempSin = capd::TypeTraits<T>::zero();
      register T tempCos = capd::TypeTraits<T>::zero();
      for(int j=0;j<=coeffNo;++j)
      {
        tempSin += leftDer[coeffNo-j]*right[j];
        tempCos -= leftDer[coeffNo-j]*result[j];
      }
      *resultDer = tempSin;
      *rightDer = tempCos;
    }
  } // evalC1

  template<class T>
  inline void evalC2(T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC1(left,right,result,dim,order,coeffNo);

    int s = dim*order;
    // begin of C^1
    T* leftDer = left + order;
    T* rightDer = right + order;
    T* resultDer = result + order;
    // begin of C^2
    T* leftHess = leftDer + s;
    T* rightHess = rightDer + s;
    T* resultHess = resultDer + s;

    for(int derNo=0;derNo<dim;++derNo,leftDer+=order,rightDer+=order,resultDer+=order)
    {
      // case dx^2
      register T tempSin1 = TypeTraits<T>::zero();
      register T tempSin2 = TypeTraits<T>::zero();
      register T tempCos1 = TypeTraits<T>::zero();
      register T tempCos2 = TypeTraits<T>::zero();
      for(int i=0,j=coeffNo;i<=coeffNo;++i,--j)
      {
        tempSin1 += leftDer[i]*rightDer[j];
        tempSin2 += leftHess[i]*right[j];
        tempCos1 -= leftDer[i]*resultDer[j];
        tempCos2 -= leftHess[i]*result[j];
      }
      resultHess[coeffNo] = 0.5*tempSin1 + tempSin2;
      rightHess[coeffNo]  = 0.5*tempCos1 + tempCos2;

      leftHess += order;
      rightHess += order;
      resultHess += order;

      // case dxdy
      T* rightDer2 = rightDer + order;
      T* resultDer2 = resultDer + order;
      for(int derNo2=derNo+1;derNo2<dim;++derNo2,rightDer2+=order,resultDer2+=order,leftHess+=order,rightHess+=order,resultHess+=order)
      {
        tempSin1 = TypeTraits<T>::zero();
        tempCos1 = TypeTraits<T>::zero();
        for(int i=0,j=coeffNo;i<=coeffNo;++i,--j)
        {
          tempSin1 += leftDer[i] * rightDer2[j];
          tempSin1 += leftHess[i] * right[j];
          tempCos1 -= leftDer[i] * resultDer2[j];
          tempCos1 -= leftHess[i] * result[j];
        }
        resultHess[coeffNo] = tempSin1;
        rightHess[coeffNo] = tempCos1;
      }
    }
  }  // evalC2

  /// hand optimized code for third order jet propagation of sine
  template<class T>
  inline void evalC3(T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC2(left,right,result,dim,order,coeffNo);

    int i1 = order;
    for(int derNo=0;derNo<dim;++derNo,i1+=order)
    {
      int i11 = capd::autodiff::index(dim,derNo,derNo)*order;
      int i111 = capd::autodiff::index(dim,derNo,derNo,derNo)*order;
      T tempSin = TypeTraits<T>::zero();
      T tempCos = TypeTraits<T>::zero();
      // case dxdxdx
      for(int i=0,j=coeffNo;i<=coeffNo;++i,--j)
      {
        tempSin += left[i1+i] * right[i11+j];
        tempSin += 2.*left[i11+i] * right[i1+j];
        tempSin += 3.*left[i111+i]* right[j];

        tempCos -= left[i1+i] * result[i11+j];
        tempCos -= 2.*left[i11+i] * result[i1+j];
        tempCos -= 3.*left[i111+i]* result[j];
      }
      result[i111+coeffNo] = tempSin/3.;
      right[i111+coeffNo] = tempCos/3.;

      // cases dxdxdy and dxdydy, assume that x<y
      int i2 = i1+order;
      int i12 = i11+order;
      int i112 = i111 + order;
      for(int derNo2=derNo+1;derNo2<dim;++derNo2,i2+=order,i12+=order,i112+=order)
      {
        int i22 = capd::autodiff::index(dim,derNo2,derNo2)*order;
        int i122 = capd::autodiff::index(dim,derNo,derNo2,derNo2)*order;
        tempSin = TypeTraits<T>::zero();
        tempCos = TypeTraits<T>::zero();
        T tempSin2 = TypeTraits<T>::zero();
        T tempCos2 = TypeTraits<T>::zero();
        for(int i=0,j=coeffNo;i<=coeffNo;++i,--j)
        {
          tempSin += left[i1+i]*right[i22+j];  // x,yy
          tempSin += left[i12+i]*right[i2+j];  // xy,y
          tempSin += left[i122+i]*right[j];    // xyy,0

          tempSin2 += left[i2+i]*right[i11+j]; // y,xx
          tempSin2 += left[i12+i]*right[i1+j]; // xy,x
          tempSin2 += left[i112+i]*right[j];   // xxy,0

          tempCos -= left[i1+i]*result[i22+j];  // x,yy
          tempCos -= left[i12+i]*result[i2+j];  // xy,y
          tempCos -= left[i122+i]*result[j];    // xxy,0

          tempCos2 -= left[i2+i]*result[i11+j]; // y,xx
          tempCos2 -= left[i12+i]*result[i1+j]; // xy,x
          tempCos2 -= left[i112+i]*result[j];   // xxy,0
        }
        result[i112+coeffNo] = tempSin2;
        result[i122+coeffNo] = tempSin;
        right[i112+coeffNo] = tempCos2;
        right[i122+coeffNo] = tempCos;

        // case dxdydz, assume x<y<z
        int i3 = i2 + order;
        int i123 = i122 + order;
        int i23 = i22 + order;
        int i13 = i12 + order;
        for(int derNo3=derNo2+1;derNo3<dim;++derNo3,i3+=order,i123+=order,i23+=order,i13+=order)
        {
          tempSin = TypeTraits<T>::zero();
          tempCos = TypeTraits<T>::zero();
          for(int i=0,j=coeffNo;i<=coeffNo;++i,--j)
          {
            tempSin += left[i1+i]   * right[i23+j];  // x,yz
            tempSin += left[i12+i]  * right[i3+j];  // xy,z
            tempSin += left[i13+i]  * right[i2+j];  // xz,y
            tempSin += left[i123+i] * right[j];      // xyz,0

            tempCos -= left[i1+i]   * result[i23+j];  // x,yz
            tempCos -= left[i12+i]  * result[i3+j];  // xy,z
            tempCos -= left[i13+i]  * result[i2+j];  // xz,y
            tempCos -= left[i123+i] * result[j];      // xyz,0
          }
          result[i123+coeffNo] = tempSin;
          right[i123+coeffNo] = tempCos;
        }
      }
    }
  }  // evalC3


  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    switch(degree)
    {
      case 3:
        evalC3(left,right,result,dim,order,coeffNo);
        break;
      case 2:
        evalC2(left,right,result,dim,order,coeffNo);
        break;
      case 1:
        evalC1(left,right,result,dim,order,coeffNo);
        break;
      case 0:
        evalC0(left,right,result,coeffNo);
        break;
      default:
        throw std::logic_error("Jet propagation of sine is not implemented for degree>3");
    }
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    (*result) = sin(*left);
    (*right) = cos(*left);
  }

  template<class T>
  inline void evalC1HomogenousPolynomial(T* left, T* right, T* result, int dim, Order order)
  {
    T* leftDer = left + order;
    T* rightDer = right + order;
    T* resultDer = result + order;
    for(int derNo=0;derNo<dim;++derNo,leftDer+=order,rightDer+=order,resultDer+=order)
    {
      *resultDer = (*leftDer)*(*right);
      *rightDer = -(*leftDer)*(*result);
    }
  }

  template<class T>
  inline void evalC2HomogenousPolynomial(T* left, T* right, T* result, int dim, Order order)
  {
    int s = dim*order;
    // begin of C^1
    T* leftDer = left + order;
    T* rightDer = right + order;
    T* resultDer = result + order;
    // begin of C^2
    T* leftHess = leftDer + s;
    T* rightHess = rightDer + s;
    T* resultHess = resultDer + s;

    for(int derNo=0;derNo<dim;++derNo,leftDer+=order,rightDer+=order,resultDer+=order)
    {
      // case dx^2
      *resultHess = 0.5*(*leftDer)*(*rightDer) + (*leftHess)*(*right);
      *rightHess  = -0.5*(*leftDer)*(*resultDer) - (*leftHess)*(*result);

      leftHess += order;
      rightHess += order;
      resultHess += order;

      // case dxdy
      T* rightDer2 = rightDer + order;
      T* resultDer2 = resultDer + order;
      for(int derNo2=derNo+1;derNo2<dim;++derNo2,rightDer2+=order,resultDer2+=order,leftHess+=order,rightHess+=order,resultHess+=order)
      {
        *resultHess = (*leftDer) * (*rightDer2) + (*leftHess) * (*right);
        *rightHess = -(*leftDer) * (*resultDer2) - (*leftHess) * (*result);
      }
    }
  }

  template<class T>
  inline void evalC3HomogenousPolynomial(T* left, T* right, T* result, int dim, Order order)
  {
    int i1 = order;
    for(int derNo=0;derNo<dim;++derNo,i1+=order)
    {
      int i11 = capd::autodiff::index(dim,derNo,derNo)*order;
      int i111 = capd::autodiff::index(dim,derNo,derNo,derNo)*order;
      // case dxdxdx
      result[i111] = (left[i1] * right[i11] + 2.*left[i11] * right[i1])/3. + left[i111]* (*right);
      right[i111] = -(left[i1] * result[i11] + 2.*left[i11] * result[i1])/3. - left[i111]* (*result);

      // cases dxdxdy and dxdydy, assume that x<y
      int i2 = i1+order;
      int i12 = i11+order;
      int i112 = i111 + order;
      for(int derNo2=derNo+1;derNo2<dim;++derNo2,i2+=order,i12+=order,i112+=order)
      {
        int i22 = capd::autodiff::index(dim,derNo2,derNo2)*order;
        int i122 = capd::autodiff::index(dim,derNo,derNo2,derNo2)*order;

        result[i112] = left[i2]*right[i11] + left[i12]*right[i1] + left[i112]*(*right);
        result[i122] = left[i1]*right[i22] + left[i12]*right[i2] + left[i122]*(*right);
        right[i112] = -(left[i2]*result[i11] + left[i12]*result[i1] + left[i112]*(*result));
        right[i122] = -(left[i1]*result[i22] + left[i12]*result[i2] + left[i122]*(*result));

        // case dxdydz, assume x<y<z
        int i3 = i2 + order;
        int i123 = i122 + order;
        int i23 = i22 + order;
        int i13 = i12 + order;
        for(int derNo3=derNo2+1;derNo3<dim;++derNo3,i3+=order,i123+=order,i23+=order,i13+=order)
        {
          result[i123] = left[i1]*right[i23] + left[i12]*right[i3] + left[i13]*right[i2] + left[i123]*(*right);
          right[i123] = -(left[i1]*result[i23] + left[i12]*result[i3] + left[i13]*result[i2] + left[i123]*(*result));
        }
      }
    }
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {
    switch(degree)
    {
      case 3:
        evalC3HomogenousPolynomial(left,right,result,dim,order);
        break;
      case 2:
        evalC2HomogenousPolynomial(left,right,result,dim,order);
        break;
      case 1:
        evalC1HomogenousPolynomial(left,right,result,dim,order);
        break;
      case 0:
        evalC0HomogenousPolynomial(left,right,result);
        break;
      default:
        throw std::logic_error("Jet propagation of sine is not implemented for degree>3");
    }
  }
}

namespace SinConst{

  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    if(!coeffNo)
    {
      *result = sin(*left);
      *right = cos(*left);
    }
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = sin(*left);
    *right = cos(*left);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}
}

namespace SinTime{

  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    if(coeffNo)
    {
      result[coeffNo] = right[coeffNo-1]/(double)coeffNo;
      right[coeffNo] = -result[coeffNo-1]/(double)coeffNo;
    }
    else
    {
      (*result) = sin(*left);
      (*right) = cos(*left);
    }
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = sin(*left);
    *right = cos(*left);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}
}

namespace SinFunTime{

  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    Sin::evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    Sin::evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = sin(*left);
    *right = cos(*left);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}
}

// ----------------------------------------------------------------------------------

//use macro to define classes

CAPD_MAKE_CLASS_NODE(Sin);
CAPD_MAKE_CLASS_NODE(SinConst);
CAPD_MAKE_CLASS_NODE(SinTime);
CAPD_MAKE_CLASS_NODE(SinFunTime);

}} // namespace capd::autodiff

#endif
