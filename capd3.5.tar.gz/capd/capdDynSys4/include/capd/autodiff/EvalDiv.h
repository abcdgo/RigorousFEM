/// @addtogroup autodiff
/// @{

/////////////////////////////////////////////////////////////////////////////
/// @file EvalDiv.h
///
/// @author Daniel Wilczak
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) 2000-2012 by the CAPD Group.
//
// This file constitutes a part of the CAPD library,
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.ii.uj.edu.pl/ for details.

#ifndef _CAPD_AUTODIFF_EVAL_DIV_H_
#define _CAPD_AUTODIFF_EVAL_DIV_H_

#include "capd/autodiff/NodeType.h"

namespace capd{
namespace autodiff{

// -------------------- Div  -------------------------------

namespace Div
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo  )
  {
    register T temp = left[coeffNo];
    for(int j=0;j<coeffNo;++j)
      temp -= result[j] * right[coeffNo-j];
    result[coeffNo] = temp/(*right);
  }

  template<class T>
  inline void evalC1(T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);
    T* leftDer = left + order + coeffNo;
    T* rightDer = right + order;
    T* resultDer = result + order;
    for(int derNo=0;derNo<dim;++derNo,leftDer+=order,rightDer+=order,resultDer+=order)
    {
      register T temp = (*leftDer) - result[coeffNo] * (*rightDer);
      for(int j=0;j<coeffNo;++j)
        temp -= ( result[j]* rightDer[coeffNo-j] + resultDer[j] * right[coeffNo-j] );
      resultDer[coeffNo] = temp/(*right);
    }
  }

  /// hand optimized code for second order jet propagation of division
  template<class T>
  inline void evalC2(T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC1(left,right,result,dim,order,coeffNo);
    int s = dim*order;
    // begin of C^1
    T* rightDer = right+order;
    T* resultDer = result + order;
    // begin of C^2
    T* leftHess = left + order + s + coeffNo;
    T* rightHess = rightDer + s;
    T* resultHess = resultDer + s;

    for(int derNo=0;derNo<dim;++derNo,rightDer+=order,resultDer+=order)
    {
      // case dxdx
      register T temp = (*leftHess) - result[coeffNo]*(*rightHess) - resultDer[coeffNo]*(*rightDer);
      for(int i=0,j=coeffNo;i<coeffNo;++i,--j)
        temp -= ( result[i]* rightHess[j] + resultDer[i]*rightDer[j] + resultHess[i] * right[j] );
      resultHess[coeffNo] = temp/(*right);

      leftHess += order;
      rightHess += order;
      resultHess += order;

      // case dxdy
      T* resultDer2 = resultDer + order;
      T* rightDer2 = rightDer + order;
      for(int derNo2=derNo+1;derNo2<dim;++derNo2,resultDer2+=order,rightDer2+=order,leftHess+=order,rightHess+=order,resultHess+=order)
      {
        temp = (*leftHess) - result[coeffNo]*(*rightHess) - resultDer2[coeffNo]*(*rightDer) - resultDer[coeffNo]*(*rightDer2);
        for(int i=0,j=coeffNo;i<coeffNo;++i,--j)
        {
          temp -= result[i] * rightHess[j];
          temp -= resultDer[i] * rightDer2[j];
          temp -= resultDer2[i] * rightDer[j];
          temp -= resultHess[i] * right[j];
        }
        resultHess[coeffNo] = temp/(*right);
      }
    }
  }

  /// hand optimized code for second order jet propagation of division
  template<class T>
  inline void evalC3(T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC2(left,right,result,dim,order,coeffNo);
    int i1 = order;
    for(int derNo=0;derNo<dim;++derNo,i1+=order)
    {
      int i11 = capd::autodiff::index(dim,derNo,derNo)*order;
      int i111 = capd::autodiff::index(dim,derNo,derNo,derNo)*order;
      T temp = left[i111] - result[coeffNo]*right[i111] - result[i1+coeffNo]*right[i11] - result[i11+coeffNo]*right[i1];
      // case dxdxdx
      for(int i=0,j=coeffNo;i<coeffNo;++i,--j)
      {
        temp -= result[i]* right[i111+j];
        temp -= result[i1+i] * right[i11+j];
        temp -= result[i11+i] * right[i1+j];
        temp -= result[i111+i]* right[j];
      }
      result[i111+coeffNo] = temp/(*right);

      // cases dxdxdy and dxdydy, assume that x<y
      int i2 = i1+order;
      int i12 = i11+order;
      int i112 = i111 + order;
      for(int derNo2=derNo+1;derNo2<dim;++derNo2,i2+=order,i12+=order,i112+=order)
      {
        int i22 = capd::autodiff::index(dim,derNo2,derNo2)*order;
        int i122 = capd::autodiff::index(dim,derNo,derNo2,derNo2)*order;
        temp = left[i112] - result[coeffNo]     * right[i112]
                          - result[i1+coeffNo]  * right[i12]
                          - result[i2+coeffNo]  * right[i11]
                          - result[i12+coeffNo] * right[i1]
                          - result[i11+coeffNo] * right[i2];
        T temp2 = left[i122] - result[coeffNo]     * right[i122]
                             - result[i1+coeffNo]  * right[i22]
                             - result[i2+coeffNo]  * right[i12]
                             - result[i12+coeffNo] * right[i2]
                             - result[i22+coeffNo] * right[i1];
        for(int i=0,j=coeffNo;i<coeffNo;++i,--j)
        {
          temp -= result[i]*right[i112+j];    // 0,xxy
          temp -= result[i1+i]*right[i12+j];  // x,xy
          temp -= result[i2+i]*right[i11+j];  // y,xx
          temp -= result[i11+i]*right[i2+j];  // xx,y
          temp -= result[i12+i]*right[i1+j];  // xy,x
          temp -= result[i112+i]*right[j];    // xxy,0

          temp2 -= result[i]*right[i122+j];   // 0,xyy
          temp2 -= result[i1+i]*right[i22+j]; // x,yy
          temp2 -= result[i2+i]*right[i12+j]; // y,xy
          temp2 -= result[i12+i]*right[i2+j]; // xy,y
          temp2 -= result[i22+i]*right[i1+j]; // yy,x
          temp2 -= result[i122+i]*right[j];   // xyy,0
        }
        result[i112+coeffNo] = temp/(*right);
        result[i122+coeffNo] = temp2/(*right);

        // case dxdydz, assume x<y<z
        int i3 = i2+order;
        int i123 = i122+order;
        int i23 = i22 + order;
        int i13 = i12 + order;
        for(int derNo3=derNo2+1;derNo3<dim;++derNo3,i3+=order,i123+=order,i23+=order,i13+=order)
        {
          temp = left[i123] - result[coeffNo]     * right[i123]
                            - result[i1+coeffNo]  * right[i23]
                            - result[i2+coeffNo]  * right[i13]
                            - result[i3+coeffNo]  * right[i12]
                            - result[i12+coeffNo] * right[i3]
                            - result[i13+coeffNo] * right[i2]
                            - result[i23+coeffNo] * right[i1];
          for(int i=0,j=coeffNo;i<coeffNo;++i,--j)
          {
            temp -= result[i] * right[i123+j];    // 0,xyz
            temp -= result[i1+i] * right[i23+j];  // x,yz
            temp -= result[i2+i] * right[i13+j];  // y,xz
            temp -= result[i3+i] * right[i12+j];  // z,xy
            temp -= result[i12+i] * right[i3+j];  // xy,z
            temp -= result[i13+i] * right[i2+j];  // xz,y
            temp -= result[i23+i]*right[i1+j];    // yz,x
            temp -= result[i123+i]*right[j];      // xyz,0
          }
          result[i123+coeffNo] = temp/(*right);
        }
      }
    }
  }

  template<class T>
  inline void eval(int degree,T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    switch(degree)
    {
      case 3:
        evalC3(left,right,result,dim,order,coeffNo);
        break;
      case 2:
        evalC2(left,right,result,dim,order,coeffNo);
        break;
      case 1:
        evalC1(left,right,result,dim,order,coeffNo);
        break;
      case 0:
        evalC0(left,right,result,coeffNo);
        break;
      default:
        throw std::logic_error("Jet propagation of division is not implemented for degree>3");
    }
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = (*left)/(*right);
  }

  template<class T>
  inline void evalC1HomogenousPolynomial(T* left, T* right, T* result, int dim, Order order)
  {
    T* leftDer = left + order;
    T* rightDer = right + order;
    T* resultDer = result + order;
    for(int derNo=0;derNo<dim;++derNo,leftDer+=order,rightDer+=order,resultDer+=order)
      *resultDer = ((*leftDer) - (*result) * (*rightDer))/(*right);
  }

  template<class T>
  inline void evalC2HomogenousPolynomial(T* left, T* right, T* result, int dim, Order order)
  {
    int s = dim*order;
    // begin of C^1
    T* rightDer = right+order;
    T* resultDer = result + order;
    // begin of C^2
    T* leftHess = left + order + s;
    T* rightHess = rightDer + s;
    T* resultHess = resultDer + s;

    for(int derNo=0;derNo<dim;++derNo,rightDer+=order,resultDer+=order)
    {
      // case dxdx
      *resultHess = ((*leftHess) - (*result)*(*rightHess) - (*resultDer)*(*rightDer))/(*right);

      leftHess += order;
      rightHess += order;
      resultHess += order;

      // case dxdy
      T* resultDer2 = resultDer + order;
      T* rightDer2 = rightDer + order;
      for(int derNo2=derNo+1;derNo2<dim;++derNo2,resultDer2+=order,rightDer2+=order,leftHess+=order,rightHess+=order,resultHess+=order)
        *resultHess = ((*leftHess) - (*result)*(*rightHess) - (*resultDer2)*(*rightDer) - (*resultDer)*(*rightDer2))/(*right);
    }
  }

  /// hand optimized code for second order jet propagation of division
  template<class T>
  inline void evalC3HomogenousPolynomial(T* left, T* right, T* result, int dim, Order order)
  {
    int i1 = order;
    for(int derNo=0;derNo<dim;++derNo,i1+=order)
    {
      int i11 = capd::autodiff::index(dim,derNo,derNo)*order;
      int i111 = capd::autodiff::index(dim,derNo,derNo,derNo)*order;
      result[i111] = (left[i111] - (*result)*right[i111] - result[i1]*right[i11] - result[i11]*right[i1])/(*right);

      // cases dxdxdy and dxdydy, assume that x<y
      int i2 = i1+order;
      int i12 = i11+order;
      int i112 = i111 + order;
      for(int derNo2=derNo+1;derNo2<dim;++derNo2,i2+=order,i12+=order,i112+=order)
      {
        int i22 = capd::autodiff::index(dim,derNo2,derNo2)*order;
        int i122 = capd::autodiff::index(dim,derNo,derNo2,derNo2)*order;
        result[i112] = (left[i112] - (*result)* right[i112]
                          - result[i1]  * right[i12]
                          - result[i2]  * right[i11]
                          - result[i12] * right[i1]
                          - result[i11] * right[i2])/(*right);
        result[i122] = (left[i122] - (*result) * right[i122]
                             - result[i1]  * right[i22]
                             - result[i2]  * right[i12]
                             - result[i12] * right[i2]
                             - result[i22] * right[i1])/(*right);

        // case dxdydz, assume x<y<z
        int i3 = i2+order;
        int i123 = i122+order;
        int i23 = i22 + order;
        int i13 = i12 + order;
        for(int derNo3=derNo2+1;derNo3<dim;++derNo3,i3+=order,i123+=order,i23+=order,i13+=order)
        {
          result[i123] = (left[i123] - (*result) * right[i123]
                            - result[i1]  * right[i23]
                            - result[i2]  * right[i13]
                            - result[i3]  * right[i12]
                            - result[i12] * right[i3]
                            - result[i13] * right[i2]
                            - result[i23] * right[i1])/(*right);
        }
      }
    }
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {
    switch(degree)
    {
      case 3:
        evalC3HomogenousPolynomial(left,right,result,dim,order);
        break;
      case 2:
        evalC2HomogenousPolynomial(left,right,result,dim,order);
        break;
      case 1:
        evalC1HomogenousPolynomial(left,right,result,dim,order);
        break;
      case 0:
        evalC0HomogenousPolynomial(left,right,result);
        break;
      default:
        throw std::logic_error("Jet propagation of division is not implemented for degree>3");
    }
  }
}

// -------------------- DivVarByConst  -------------------------------

namespace DivVarByConst
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    result[coeffNo] = left[coeffNo]/(*right);
  }

  template<class T>
  inline void evalC1(T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    T* leftDer = left+coeffNo;
    T* resultDer = result+coeffNo;
    for(int derNo=0;derNo<=dim;++derNo,leftDer+=order,resultDer+=order)
      (*resultDer) = (*leftDer)/(*right);
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC1(left,right,result,newton(dim+degree,dim)-1,order,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = (*left)/(*right);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {
    int s = newton(dim+degree-1,dim)*order;
    left += s;
    result += s;
    for(int derNo=0;derNo<newton(dim-1+degree,degree);++derNo,left+=order,result+=order)
      *result = (*left) / (*right);
  }
}

// -------------------- DivVarByFunTime  -------------------------------

namespace DivVarByFunTime
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo  )
  {
    Div::evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void eval(int degree,T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    for(int derNo=0;derNo<newton(dim+degree,dim);++derNo,left+=order,result+=order)
      Div::evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = (*left)/(*right);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {
    DivVarByConst::evalHomogenousPolynomial(degree,left,right,result,dim,order);
  }
}

// -------------------- DivVarByTime  -------------------------------

namespace DivVarByTime
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo  )
  {
    result[coeffNo] = (left[coeffNo]-result[coeffNo-1])/(*right);
  }

  template<class T>
  inline void eval(int degree,T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    for(int derNo=0;derNo<newton(dim+degree,dim);++derNo,left+=order,result+=order)
      evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = (*left)/(*right);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {
    DivVarByConst::evalHomogenousPolynomial(degree,left,right,result,dim,order);
  }
}

// -------------------- DivTimeByConst -------------------------------

namespace DivTimeByConst
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    if(coeffNo<=1)
      result[coeffNo] = left[coeffNo] / (*right);
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = (*left) / (*right);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}
}

// -------------------- DivFunTimeByConst -------------------------------

namespace DivFunTimeByConst
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    result[coeffNo] = left[coeffNo] / (*right);
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = (*left) / (*right);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}
}

// -------------------- DivFunTimeByTime -------------------------------

namespace DivFunTimeByTime
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    DivVarByTime::evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = (*left) / (*right);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}
}

// -------------------- DivFunTimeByFunTime -------------------------------

namespace DivFunTimeByFunTime
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    Div::evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = (*left) / (*right);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}
}

// -------------------- DivConstByConst -------------------------------

namespace DivConstByConst
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    if(coeffNo)
      *result = (*left) / (*right);
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = (*left) / (*right);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}
}

// ----------------------------------------------------------------------------------

//use macro to define classes

CAPD_MAKE_CLASS_NODE(Div);
CAPD_MAKE_CLASS_NODE(DivVarByConst);
CAPD_MAKE_CLASS_NODE(DivVarByTime);
CAPD_MAKE_CLASS_NODE(DivVarByFunTime);
CAPD_MAKE_CLASS_NODE(DivTimeByConst);
CAPD_MAKE_CLASS_NODE(DivFunTimeByConst);
CAPD_MAKE_CLASS_NODE(DivFunTimeByTime);
CAPD_MAKE_CLASS_NODE(DivFunTimeByFunTime);
CAPD_MAKE_CLASS_NODE(DivConstByConst);

}} // namespace capd::autodiff

#endif
