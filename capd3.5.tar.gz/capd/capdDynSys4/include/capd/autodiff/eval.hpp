/// @addtogroup autodiff
/// @{

/////////////////////////////////////////////////////////////////////////////
/// @file eval.hpp
///
/// @author Daniel Wilczak
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) 2000-2012 by the CAPD Group.
//
// This file constitutes a part of the CAPD library,
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.ii.uj.edu.pl/ for details.

#ifndef _CAPD_AUTODIFF_EVAL_HPP_
#define _CAPD_AUTODIFF_EVAL_HPP_

#define CAPD_EVAL(op,Namespace)                         case capd::autodiff::op : Namespace::eval(degree,left,right,result,dim,order,coeffNo); break;
#define CAPD_EVALC0(op,Namespace)                       case capd::autodiff::op : Namespace::evalC0(left,right,result,coeffNo); break;
#define CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(op,Namespace)   case capd::autodiff::op : Namespace::evalHomogenousPolynomial(degree,left,right,result,dim,order); break;
#define CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(op,Namespace) case capd::autodiff::op : Namespace::evalC0HomogenousPolynomial(left,right,result); break;

#define CAPD_MAKE_NODE(NodeName,ClassName,left,right,result) case NodeName : { p = new ClassName##Node<T>; p->left = left; p->right = right; p->result = result; break; }

#define CAPD_USE_MACROS

#include <stdexcept>
#include <sstream>

#include "capd/autodiff/DagIndexer.h"
#include "capd/autodiff/EvalAdd.h"
#include "capd/autodiff/EvalDiv.h"
#include "capd/autodiff/EvalExp.h"
#include "capd/autodiff/EvalLog.h"
#include "capd/autodiff/EvalMul.h"
//#include "capd/autodiff/EvalNaturalPow.h"
#include "capd/autodiff/EvalPow.h"
#include "capd/autodiff/EvalSinCos.h"
#include "capd/autodiff/EvalSqr.h"
#include "capd/autodiff/EvalSqrt.h"
#include "capd/autodiff/EvalSub.h"
#include "capd/autodiff/EvalUnaryMinus.h"

#include "capd/map/Parser.h"

namespace capd{
namespace autodiff{

template<class T>
void Int4ToAbstractNode(const std::vector<MyNode>& node, std::vector<AbstractNode<T>* >& out, JetSize jetSize, T* data)
{
  out.resize(node.size());
  for(unsigned i=0;i<node.size();++i)
  {
    AbstractNode<T>* p;
    T* left = data + jetSize*node[i].left;
    T* right = data + jetSize*node[i].right;
    T* result = data + jetSize*node[i].result;

    switch(node[i].op)
    {
    CAPD_MAKE_NODE(NODE_ADD,Add,left,right,result);
    CAPD_MAKE_NODE(NODE_CONST_PLUS_VAR,ConstPlusVar,left,right,result);
    CAPD_MAKE_NODE(NODE_CONST_PLUS_CONST,ConstPlusConst,left,right,result);
    CAPD_MAKE_NODE(NODE_CONST_PLUS_TIME,ConstPlusTime,left,right,result);
    CAPD_MAKE_NODE(NODE_CONST_PLUS_FUNTIME,ConstPlusFunTime,left,right,result);
    CAPD_MAKE_NODE(NODE_TIME_PLUS_VAR,TimePlusVar,left,right,result);
    CAPD_MAKE_NODE(NODE_TIME_PLUS_FUNTIME,TimePlusFunTime,left,right,result);
    CAPD_MAKE_NODE(NODE_FUNTIME_PLUS_VAR,FunTimePlusVar,left,right,result);
    CAPD_MAKE_NODE(NODE_FUNTIME_PLUS_FUNTIME,FunTimePlusFunTime,left,right,result);

    CAPD_MAKE_NODE(NODE_SUB,Sub,left,right,result);
    CAPD_MAKE_NODE(NODE_CONST_MINUS_CONST,ConstMinusConst,left,right,result);
    CAPD_MAKE_NODE(NODE_CONST_MINUS_VAR,ConstMinusVar,left,right,result);
    CAPD_MAKE_NODE(NODE_CONST_MINUS_TIME,ConstMinusTime,left,right,result);
    CAPD_MAKE_NODE(NODE_CONST_MINUS_FUNTIME,ConstMinusFunTime,left,right,result);
    CAPD_MAKE_NODE(NODE_TIME_MINUS_CONST,TimeMinusConst,left,right,result);
    CAPD_MAKE_NODE(NODE_TIME_MINUS_FUNTIME,TimeMinusFunTime,left,right,result);
    CAPD_MAKE_NODE(NODE_TIME_MINUS_VAR,TimeMinusVar,left,right,result);
    CAPD_MAKE_NODE(NODE_FUNTIME_MINUS_CONST,FunTimeMinusConst,left,right,result);
    CAPD_MAKE_NODE(NODE_FUNTIME_MINUS_TIME,FunTimeMinusTime,left,right,result);
    CAPD_MAKE_NODE(NODE_FUNTIME_MINUS_FUNTIME,FunTimeMinusFunTime,left,right,result);
    CAPD_MAKE_NODE(NODE_FUNTIME_MINUS_VAR,FunTimeMinusVar,left,right,result);
    CAPD_MAKE_NODE(NODE_VAR_MINUS_CONST,VarMinusConst,left,right,result);
    CAPD_MAKE_NODE(NODE_VAR_MINUS_TIME,VarMinusTime,left,right,result);
    CAPD_MAKE_NODE(NODE_VAR_MINUS_FUNTIME,VarMinusFunTime,left,right,result);

    CAPD_MAKE_NODE(NODE_UNARY_MINUS,UnaryMinus,left,right,result);
    CAPD_MAKE_NODE(NODE_UNARY_MINUS_CONST,UnaryMinusConst,left,right,result);
    CAPD_MAKE_NODE(NODE_UNARY_MINUS_TIME,UnaryMinusTime,left,right,result);
    CAPD_MAKE_NODE(NODE_UNARY_MINUS_FUNTIME,UnaryMinusFunTime,left,right,result);

    CAPD_MAKE_NODE(NODE_MUL,Mul,left,right,result);
    CAPD_MAKE_NODE(NODE_MUL_CONST_BY_VAR,MulConstByVar,left,right,result);
    CAPD_MAKE_NODE(NODE_MUL_CONST_BY_CONST,MulConstByConst,left,right,result);
    CAPD_MAKE_NODE(NODE_MUL_CONST_BY_TIME,MulConstByTime,left,right,result);
    CAPD_MAKE_NODE(NODE_MUL_CONST_BY_FUNTIME,MulConstByFunTime,left,right,result);
    CAPD_MAKE_NODE(NODE_MUL_TIME_BY_VAR,MulTimeByVar,left,right,result);
    CAPD_MAKE_NODE(NODE_MUL_TIME_BY_FUNTIME,MulTimeByFunTime,left,right,result);
    CAPD_MAKE_NODE(NODE_MUL_FUNTIME_BY_VAR,MulFunTimeByVar,left,right,result);
    CAPD_MAKE_NODE(NODE_MUL_FUNTIME_BY_FUNTIME,MulFunTimeByFunTime,left,right,result);

    CAPD_MAKE_NODE(NODE_DIV,Div,left,right,result);
    CAPD_MAKE_NODE(NODE_DIV_VAR_BY_CONST,DivVarByConst,left,right,result);
    CAPD_MAKE_NODE(NODE_DIV_VAR_BY_TIME,DivVarByTime,left,right,result);
    CAPD_MAKE_NODE(NODE_DIV_VAR_BY_FUNTIME,DivVarByFunTime,left,right,result);
    CAPD_MAKE_NODE(NODE_DIV_TIME_BY_CONST,DivTimeByConst,left,right,result);
    CAPD_MAKE_NODE(NODE_DIV_FUNTIME_BY_CONST,DivFunTimeByConst,left,right,result);
    CAPD_MAKE_NODE(NODE_DIV_FUNTIME_BY_TIME,DivFunTimeByTime,left,right,result);
    CAPD_MAKE_NODE(NODE_DIV_FUNTIME_BY_FUNTIME,DivFunTimeByFunTime,left,right,result);
    CAPD_MAKE_NODE(NODE_DIV_CONST_BY_CONST,DivConstByConst,left,right,result);

    CAPD_MAKE_NODE(NODE_SQR,Sqr,left,right,result);
    CAPD_MAKE_NODE(NODE_SQR_CONST,SqrConst,left,right,result);
    CAPD_MAKE_NODE(NODE_SQR_TIME,SqrTime,left,right,result);
    CAPD_MAKE_NODE(NODE_SQR_FUNTIME,SqrFunTime,left,right,result);
    CAPD_MAKE_NODE(NODE_SQRT,Sqrt,left,right,result);
    CAPD_MAKE_NODE(NODE_SQRT_CONST,SqrtConst,left,right,result);
    CAPD_MAKE_NODE(NODE_SQRT_TIME,SqrtTime,left,right,result);
    CAPD_MAKE_NODE(NODE_SQRT_FUNTIME,SqrtFunTime,left,right,result);

    CAPD_MAKE_NODE(NODE_SIN,Sin,left,right,result);
    CAPD_MAKE_NODE(NODE_SIN_CONST,SinConst,left,right,result);
    CAPD_MAKE_NODE(NODE_SIN_TIME,SinTime,left,right,result);
    CAPD_MAKE_NODE(NODE_SIN_FUNTIME,SinFunTime,left,right,result);

    CAPD_MAKE_NODE(NODE_EXP,Exp,left,right,result);
    CAPD_MAKE_NODE(NODE_EXP_CONST,ExpConst,left,right,result);
    CAPD_MAKE_NODE(NODE_EXP_TIME,ExpTime,left,right,result);
    CAPD_MAKE_NODE(NODE_EXP_FUNTIME,ExpFunTime,left,right,result);

    CAPD_MAKE_NODE(NODE_LOG,Log,left,right,result);
    CAPD_MAKE_NODE(NODE_LOG_CONST,LogConst,left,right,result);
    CAPD_MAKE_NODE(NODE_LOG_TIME,LogTime,left,right,result);
    CAPD_MAKE_NODE(NODE_LOG_FUNTIME,LogFunTime,left,right,result);

    default:
      std::ostringstream out;
      out << "Implementation error! Node no. " << node[i].op << " is missed in switch-case block in function evaluating DAG.\nPlease report this bug to developers!\n ";
      throw std::logic_error(out.str());
    }
    out[i] = p;
  }
}

// ---------------------------------------------------------------------

template<class T>
struct Eval{
  typedef void (*EvalFun)(int degree, T* left, T* right, T*result, int dim, Order order, CoeffNo coeffNo);
  typedef void (*EvalC0Fun)(T* left, T* right, T*result, CoeffNo coeffNo);
  typedef void (*EvalHomogenousFun)(int degree, T* left, T* right, T*result, int dim, Order order);
  typedef void (*EvalC0HomogenousFun)(T* left, T* right, T*result);
  const static EvalFun f[];
  const static EvalC0Fun c0f[];
  const static EvalHomogenousFun hf[];
  const static EvalC0HomogenousFun c0hf[];
};

// note here we MUST preserve order of NodeTypes
template<class ScalarT>
const typename Eval<ScalarT>::EvalFun Eval<ScalarT>::f[] = {
    // -------------- ADD --------------
    Add::eval,
    ConstPlusVar::eval,
    ConstPlusConst::eval,
    ConstPlusTime::eval,
    ConstPlusFunTime::eval,
    TimePlusVar::eval,
    TimePlusFunTime::eval,
    FunTimePlusVar::eval,
    FunTimePlusFunTime::eval,
    // -------------- SUB --------------
    Sub::eval,
    ConstMinusConst::eval,
    ConstMinusVar::eval,
    ConstMinusTime::eval,
    ConstMinusFunTime::eval,
    TimeMinusConst::eval,
    TimeMinusFunTime::eval,
    TimeMinusVar::eval,
    FunTimeMinusConst::eval,
    FunTimeMinusTime::eval,
    FunTimeMinusFunTime::eval,
    FunTimeMinusVar::eval,
    VarMinusConst::eval,
    VarMinusTime::eval,
    VarMinusFunTime::eval,
    // ----------- UNARY MINUS-------------
    UnaryMinus::eval,
    UnaryMinusConst::eval,
    UnaryMinusTime::eval,
    UnaryMinusFunTime::eval,
    // ------------- MUL ------------------
    Mul::eval,
    MulConstByVar::eval,
    MulConstByConst::eval,
    MulConstByTime::eval,
    MulConstByFunTime::eval,
    MulTimeByVar::eval,
    MulTimeByFunTime::eval,
    MulFunTimeByVar::eval,
    MulFunTimeByFunTime::eval,
    // ------------- DIV ------------------
    Div::eval,
    DivVarByConst::eval,
    DivVarByTime::eval,
    DivVarByFunTime::eval,
    DivTimeByConst::eval,
    DivFunTimeByConst::eval,
    DivFunTimeByTime::eval,
    DivFunTimeByFunTime::eval,
    DivConstByConst::eval,
    // ------------- SQR SQRT------------------
    Sqr::eval,
    SqrConst::eval,
    SqrTime::eval,
    SqrFunTime::eval,
    Sqrt::eval,
    SqrtConst::eval,
    SqrtTime::eval,
    SqrtFunTime::eval
};

// note here we MUST preserve order of NodeTypes
template<class ScalarT>
const typename Eval<ScalarT>::EvalC0Fun Eval<ScalarT>::c0f[] = {
    // -------------- ADD SUB --------------
    Add::evalC0,
    ConstPlusVar::evalC0,
    ConstPlusConst::evalC0,
    ConstPlusTime::evalC0,
    ConstPlusFunTime::evalC0,
    TimePlusVar::evalC0,
    TimePlusFunTime::evalC0,
    FunTimePlusVar::evalC0,
    FunTimePlusFunTime::evalC0,
    // -------------- SUB --------------
    Sub::evalC0,
    ConstMinusConst::evalC0,
    ConstMinusVar::evalC0,
    ConstMinusTime::evalC0,
    ConstMinusFunTime::evalC0,
    TimeMinusConst::evalC0,
    TimeMinusFunTime::evalC0,
    TimeMinusVar::evalC0,
    FunTimeMinusConst::evalC0,
    FunTimeMinusTime::evalC0,
    FunTimeMinusFunTime::evalC0,
    FunTimeMinusVar::evalC0,
    VarMinusConst::evalC0,
    VarMinusTime::evalC0,
    VarMinusFunTime::evalC0,
    // ----------- UNARY MINUS-------------
    UnaryMinus::evalC0,
    UnaryMinusConst::evalC0,
    UnaryMinusTime::evalC0,
    UnaryMinusFunTime::evalC0,
    // ------------- MUL ------------------
    Mul::evalC0,
    MulConstByVar::evalC0,
    MulConstByConst::evalC0,
    MulConstByTime::evalC0,
    MulConstByFunTime::evalC0,
    MulTimeByVar::evalC0,
    MulTimeByFunTime::evalC0,
    MulFunTimeByVar::evalC0,
    MulFunTimeByFunTime::evalC0,
    // ------------- DIV ------------------
    Div::evalC0,
    DivVarByConst::evalC0,
    DivVarByTime::evalC0,
    DivVarByFunTime::evalC0,
    DivTimeByConst::evalC0,
    DivFunTimeByConst::evalC0,
    DivFunTimeByTime::evalC0,
    DivFunTimeByFunTime::evalC0,
    DivConstByConst::evalC0,
    // ------------- SQR SQRT ------------------
    Sqr::evalC0,
    SqrConst::evalC0,
    SqrTime::evalC0,
    SqrFunTime::evalC0,
    Sqrt::evalC0,
    SqrtConst::evalC0,
    SqrtTime::evalC0,
    SqrtFunTime::evalC0
};

// note here we MUST preserve order of NodeTypes
template<class ScalarT>
const typename Eval<ScalarT>::EvalHomogenousFun Eval<ScalarT>::hf[] = {
    // -------------- ADD SUB --------------
    Add::evalHomogenousPolynomial,
    ConstPlusVar::evalHomogenousPolynomial,
    ConstPlusConst::evalHomogenousPolynomial,
    ConstPlusTime::evalHomogenousPolynomial,
    ConstPlusFunTime::evalHomogenousPolynomial,
    TimePlusVar::evalHomogenousPolynomial,
    TimePlusFunTime::evalHomogenousPolynomial,
    FunTimePlusVar::evalHomogenousPolynomial,
    FunTimePlusFunTime::evalHomogenousPolynomial,
    // -------------- SUB --------------
    Sub::evalHomogenousPolynomial,
    ConstMinusConst::evalHomogenousPolynomial,
    ConstMinusVar::evalHomogenousPolynomial,
    ConstMinusTime::evalHomogenousPolynomial,
    ConstMinusFunTime::evalHomogenousPolynomial,
    TimeMinusConst::evalHomogenousPolynomial,
    TimeMinusFunTime::evalHomogenousPolynomial,
    TimeMinusVar::evalHomogenousPolynomial,
    FunTimeMinusConst::evalHomogenousPolynomial,
    FunTimeMinusTime::evalHomogenousPolynomial,
    FunTimeMinusFunTime::evalHomogenousPolynomial,
    FunTimeMinusVar::evalHomogenousPolynomial,
    VarMinusConst::evalHomogenousPolynomial,
    VarMinusTime::evalHomogenousPolynomial,
    VarMinusFunTime::evalHomogenousPolynomial,
    // ----------- UNARY MINUS-------------
    UnaryMinus::evalHomogenousPolynomial,
    UnaryMinusConst::evalHomogenousPolynomial,
    UnaryMinusTime::evalHomogenousPolynomial,
    UnaryMinusFunTime::evalHomogenousPolynomial,
    // ------------- MUL ------------------
    Mul::evalHomogenousPolynomial,
    MulConstByVar::evalHomogenousPolynomial,
    MulConstByConst::evalHomogenousPolynomial,
    MulConstByTime::evalHomogenousPolynomial,
    MulConstByFunTime::evalHomogenousPolynomial,
    MulTimeByVar::evalHomogenousPolynomial,
    MulTimeByFunTime::evalHomogenousPolynomial,
    MulFunTimeByVar::evalHomogenousPolynomial,
    MulFunTimeByFunTime::evalHomogenousPolynomial,
    // ------------- DIV ------------------
    Div::evalHomogenousPolynomial,
    DivVarByConst::evalHomogenousPolynomial,
    DivVarByTime::evalHomogenousPolynomial,
    DivVarByFunTime::evalHomogenousPolynomial,
    DivTimeByConst::evalHomogenousPolynomial,
    DivFunTimeByConst::evalHomogenousPolynomial,
    DivFunTimeByTime::evalHomogenousPolynomial,
    DivFunTimeByFunTime::evalHomogenousPolynomial,
    DivConstByConst::evalHomogenousPolynomial,
    // ------------- SQR ------------------
    Sqr::evalHomogenousPolynomial,
    SqrConst::evalHomogenousPolynomial,
    SqrTime::evalHomogenousPolynomial,
    SqrFunTime::evalHomogenousPolynomial,
    Sqrt::evalHomogenousPolynomial,
    SqrtConst::evalHomogenousPolynomial,
    SqrtTime::evalHomogenousPolynomial,
    SqrtFunTime::evalHomogenousPolynomial

};

// note here we MUST preserve order of NodeTypes
template<class ScalarT>
const typename Eval<ScalarT>::EvalC0HomogenousFun Eval<ScalarT>::c0hf[] = {
    // -------------- ADD --------------
    Add::evalC0HomogenousPolynomial,
    ConstPlusVar::evalC0HomogenousPolynomial,
    ConstPlusConst::evalC0HomogenousPolynomial,
    ConstPlusTime::evalC0HomogenousPolynomial,
    ConstPlusFunTime::evalC0HomogenousPolynomial,
    TimePlusVar::evalC0HomogenousPolynomial,
    TimePlusFunTime::evalC0HomogenousPolynomial,
    FunTimePlusVar::evalC0HomogenousPolynomial,
    FunTimePlusFunTime::evalC0HomogenousPolynomial,
    // -------------- SUB --------------
    Sub::evalC0HomogenousPolynomial,
    ConstMinusConst::evalC0HomogenousPolynomial,
    ConstMinusVar::evalC0HomogenousPolynomial,
    ConstMinusTime::evalC0HomogenousPolynomial,
    ConstMinusFunTime::evalC0HomogenousPolynomial,
    TimeMinusConst::evalC0HomogenousPolynomial,
    TimeMinusFunTime::evalC0HomogenousPolynomial,
    TimeMinusVar::evalC0HomogenousPolynomial,
    FunTimeMinusConst::evalC0HomogenousPolynomial,
    FunTimeMinusTime::evalC0HomogenousPolynomial,
    FunTimeMinusFunTime::evalC0HomogenousPolynomial,
    FunTimeMinusVar::evalC0HomogenousPolynomial,
    VarMinusConst::evalC0HomogenousPolynomial,
    VarMinusTime::evalC0HomogenousPolynomial,
    VarMinusFunTime::evalC0HomogenousPolynomial,
    // ----------- UNARY MINUS-------------
    UnaryMinus::evalC0HomogenousPolynomial,
    UnaryMinusConst::evalC0HomogenousPolynomial,
    UnaryMinusTime::evalC0HomogenousPolynomial,
    UnaryMinusFunTime::evalC0HomogenousPolynomial,
    // ------------- MUL ------------------
    Mul::evalC0HomogenousPolynomial,
    MulConstByVar::evalC0HomogenousPolynomial,
    MulConstByConst::evalC0HomogenousPolynomial,
    MulConstByTime::evalC0HomogenousPolynomial,
    MulConstByFunTime::evalC0HomogenousPolynomial,
    MulTimeByVar::evalC0HomogenousPolynomial,
    MulTimeByFunTime::evalC0HomogenousPolynomial,
    MulFunTimeByVar::evalC0HomogenousPolynomial,
    MulFunTimeByFunTime::evalC0HomogenousPolynomial,
    // ------------- DIV ------------------
    Div::evalC0HomogenousPolynomial,
    DivVarByConst::evalC0HomogenousPolynomial,
    DivVarByTime::evalC0HomogenousPolynomial,
    DivVarByFunTime::evalC0HomogenousPolynomial,
    DivTimeByConst::evalC0HomogenousPolynomial,
    DivFunTimeByConst::evalC0HomogenousPolynomial,
    DivFunTimeByTime::evalC0HomogenousPolynomial,
    DivFunTimeByFunTime::evalC0HomogenousPolynomial,
    DivConstByConst::evalC0HomogenousPolynomial,
    // ------------- SQR ------------------
    Sqr::evalC0HomogenousPolynomial,
    SqrConst::evalC0HomogenousPolynomial,
    SqrTime::evalC0HomogenousPolynomial,
    SqrFunTime::evalC0HomogenousPolynomial,
    Sqrt::evalC0HomogenousPolynomial,
    SqrtConst::evalC0HomogenousPolynomial,
    SqrtTime::evalC0HomogenousPolynomial,
    SqrtFunTime::evalC0HomogenousPolynomial

};

// ---------------------------------------------------------------------

template<class Scalar>
void eval(int degree, const std::vector<MyNode>& nodes, int dim, Order order, CoeffNo coeffNo, JetSize jetSize, Scalar* data)
{
  typename std::vector<MyNode>::const_iterator b = nodes.begin(), e = nodes.end();
  for(;b!=e;++b)
  {
    Scalar* left = data + jetSize*b->left;
    Scalar* right = data + jetSize*b->right;
    Scalar* result = data + jetSize*b->result;
#ifdef CAPD_USE_MACROS
    switch(b->op)
    {
      CAPD_EVAL(NODE_ADD,Add);
      CAPD_EVAL(NODE_CONST_PLUS_VAR,ConstPlusVar);
      CAPD_EVAL(NODE_CONST_PLUS_CONST,ConstPlusConst);
      CAPD_EVAL(NODE_CONST_PLUS_TIME,ConstPlusTime);
      CAPD_EVAL(NODE_CONST_PLUS_FUNTIME,ConstPlusFunTime);
      CAPD_EVAL(NODE_TIME_PLUS_VAR,TimePlusVar);
      CAPD_EVAL(NODE_TIME_PLUS_FUNTIME,TimePlusFunTime);
      CAPD_EVAL(NODE_FUNTIME_PLUS_VAR,FunTimePlusVar);
      CAPD_EVAL(NODE_FUNTIME_PLUS_FUNTIME,FunTimePlusFunTime);

      CAPD_EVAL(NODE_SUB,Sub);
      CAPD_EVAL(NODE_CONST_MINUS_CONST,ConstMinusConst);
      CAPD_EVAL(NODE_CONST_MINUS_VAR,ConstMinusVar);
      CAPD_EVAL(NODE_CONST_MINUS_TIME,ConstMinusTime);
      CAPD_EVAL(NODE_CONST_MINUS_FUNTIME,ConstMinusFunTime);
      CAPD_EVAL(NODE_TIME_MINUS_CONST,TimeMinusConst);
      CAPD_EVAL(NODE_TIME_MINUS_FUNTIME,TimeMinusFunTime);
      CAPD_EVAL(NODE_TIME_MINUS_VAR,TimeMinusVar);
      CAPD_EVAL(NODE_FUNTIME_MINUS_CONST,FunTimeMinusConst);
      CAPD_EVAL(NODE_FUNTIME_MINUS_TIME,FunTimeMinusTime);
      CAPD_EVAL(NODE_FUNTIME_MINUS_FUNTIME,FunTimeMinusFunTime);
      CAPD_EVAL(NODE_FUNTIME_MINUS_VAR,FunTimeMinusVar);
      CAPD_EVAL(NODE_VAR_MINUS_CONST,VarMinusConst);
      CAPD_EVAL(NODE_VAR_MINUS_TIME,VarMinusTime);
      CAPD_EVAL(NODE_VAR_MINUS_FUNTIME,VarMinusFunTime);

      CAPD_EVAL(NODE_UNARY_MINUS,UnaryMinus);
      CAPD_EVAL(NODE_UNARY_MINUS_CONST,UnaryMinusConst);
      CAPD_EVAL(NODE_UNARY_MINUS_TIME,UnaryMinusTime);
      CAPD_EVAL(NODE_UNARY_MINUS_FUNTIME,UnaryMinusFunTime);

      CAPD_EVAL(NODE_MUL,Mul);
      CAPD_EVAL(NODE_MUL_CONST_BY_VAR,MulConstByVar);
      CAPD_EVAL(NODE_MUL_CONST_BY_CONST,MulConstByConst);
      CAPD_EVAL(NODE_MUL_CONST_BY_TIME,MulConstByTime);
      CAPD_EVAL(NODE_MUL_CONST_BY_FUNTIME,MulConstByFunTime);
      CAPD_EVAL(NODE_MUL_TIME_BY_VAR,MulTimeByVar);
      CAPD_EVAL(NODE_MUL_TIME_BY_FUNTIME,MulTimeByFunTime);
      CAPD_EVAL(NODE_MUL_FUNTIME_BY_VAR,MulFunTimeByVar);
      CAPD_EVAL(NODE_MUL_FUNTIME_BY_FUNTIME,MulFunTimeByFunTime);

      CAPD_EVAL(NODE_DIV,Div);
      CAPD_EVAL(NODE_DIV_VAR_BY_CONST,DivVarByConst);
      CAPD_EVAL(NODE_DIV_VAR_BY_TIME,DivVarByTime);
      CAPD_EVAL(NODE_DIV_VAR_BY_FUNTIME,DivVarByFunTime);
      CAPD_EVAL(NODE_DIV_TIME_BY_CONST,DivTimeByConst);
      CAPD_EVAL(NODE_DIV_FUNTIME_BY_CONST,DivFunTimeByConst);
      CAPD_EVAL(NODE_DIV_FUNTIME_BY_TIME,DivFunTimeByTime);
      CAPD_EVAL(NODE_DIV_FUNTIME_BY_FUNTIME,DivFunTimeByFunTime);
      CAPD_EVAL(NODE_DIV_CONST_BY_CONST,DivConstByConst);

      CAPD_EVAL(NODE_SQR,Sqr);
      CAPD_EVAL(NODE_SQR_CONST,SqrConst);
      CAPD_EVAL(NODE_SQR_TIME,SqrTime);
      CAPD_EVAL(NODE_SQR_FUNTIME,SqrFunTime);
      CAPD_EVAL(NODE_SQRT,Sqrt);
      CAPD_EVAL(NODE_SQRT_CONST,SqrtConst);
      CAPD_EVAL(NODE_SQRT_TIME,SqrtTime);
      CAPD_EVAL(NODE_SQRT_FUNTIME,SqrtFunTime);

      CAPD_EVAL(NODE_SIN,Sin);
      CAPD_EVAL(NODE_SIN_CONST,SinConst);
      CAPD_EVAL(NODE_SIN_TIME,SinTime);
      CAPD_EVAL(NODE_SIN_FUNTIME,SinFunTime);

      CAPD_EVAL(NODE_EXP,Exp);
      CAPD_EVAL(NODE_EXP_CONST,ExpConst);
      CAPD_EVAL(NODE_EXP_TIME,ExpTime);
      CAPD_EVAL(NODE_EXP_FUNTIME,ExpFunTime);

      CAPD_EVAL(NODE_LOG,Log);
      CAPD_EVAL(NODE_LOG_CONST,LogConst);
      CAPD_EVAL(NODE_LOG_TIME,LogTime);
      CAPD_EVAL(NODE_LOG_FUNTIME,LogFunTime);

    default:
      std::ostringstream out;
      out << "Implementation error! Node no. " << b->op << " is missed in switch-case block in function evaluating DAG.\nPlease report this bug to developers!\n ";
      throw std::logic_error(out.str());
}
#else
    Eval<Scalar>::f[b->op](degree,left,right,result,dim,order,coeffNo);
#endif
  }
}

// ---------------------------------------------------------------------

template<class Scalar>
void eval(const std::vector<MyNode>& nodes, CoeffNo coeffNo, JetSize jetSize, Scalar* data)
{
  typename std::vector<MyNode>::const_iterator b = nodes.begin(), e = nodes.end();
  for(;b!=e;++b)
  {
    Scalar* left = data + jetSize*b->left;
    Scalar* right = data + jetSize*b->right;
    Scalar* result = data + jetSize*b->result;
#ifdef CAPD_USE_MACROS
    switch(b->op)
    {
      CAPD_EVALC0(NODE_ADD,Add);
      CAPD_EVALC0(NODE_CONST_PLUS_VAR,ConstPlusVar);
      CAPD_EVALC0(NODE_CONST_PLUS_CONST,ConstPlusConst);
      CAPD_EVALC0(NODE_CONST_PLUS_TIME,ConstPlusTime);
      CAPD_EVALC0(NODE_CONST_PLUS_FUNTIME,ConstPlusFunTime);
      CAPD_EVALC0(NODE_TIME_PLUS_VAR,TimePlusVar);
      CAPD_EVALC0(NODE_TIME_PLUS_FUNTIME,TimePlusFunTime);
      CAPD_EVALC0(NODE_FUNTIME_PLUS_VAR,FunTimePlusVar);
      CAPD_EVALC0(NODE_FUNTIME_PLUS_FUNTIME,FunTimePlusFunTime);

      CAPD_EVALC0(NODE_SUB,Sub);
      CAPD_EVALC0(NODE_CONST_MINUS_CONST,ConstMinusConst);
      CAPD_EVALC0(NODE_CONST_MINUS_VAR,ConstMinusVar);
      CAPD_EVALC0(NODE_CONST_MINUS_TIME,ConstMinusTime);
      CAPD_EVALC0(NODE_CONST_MINUS_FUNTIME,ConstMinusFunTime);
      CAPD_EVALC0(NODE_TIME_MINUS_CONST,TimeMinusConst);
      CAPD_EVALC0(NODE_TIME_MINUS_FUNTIME,TimeMinusFunTime);
      CAPD_EVALC0(NODE_TIME_MINUS_VAR,TimeMinusVar);
      CAPD_EVALC0(NODE_FUNTIME_MINUS_CONST,FunTimeMinusConst);
      CAPD_EVALC0(NODE_FUNTIME_MINUS_TIME,FunTimeMinusTime);
      CAPD_EVALC0(NODE_FUNTIME_MINUS_FUNTIME,FunTimeMinusFunTime);
      CAPD_EVALC0(NODE_FUNTIME_MINUS_VAR,FunTimeMinusVar);
      CAPD_EVALC0(NODE_VAR_MINUS_CONST,VarMinusConst);
      CAPD_EVALC0(NODE_VAR_MINUS_TIME,VarMinusTime);
      CAPD_EVALC0(NODE_VAR_MINUS_FUNTIME,VarMinusFunTime);

      CAPD_EVALC0(NODE_UNARY_MINUS,UnaryMinus);
      CAPD_EVALC0(NODE_UNARY_MINUS_CONST,UnaryMinusConst);
      CAPD_EVALC0(NODE_UNARY_MINUS_TIME,UnaryMinusTime);
      CAPD_EVALC0(NODE_UNARY_MINUS_FUNTIME,UnaryMinusFunTime);

      CAPD_EVALC0(NODE_MUL,Mul);
      CAPD_EVALC0(NODE_MUL_CONST_BY_VAR,MulConstByVar);
      CAPD_EVALC0(NODE_MUL_CONST_BY_CONST,MulConstByConst);
      CAPD_EVALC0(NODE_MUL_CONST_BY_TIME,MulConstByTime);
      CAPD_EVALC0(NODE_MUL_CONST_BY_FUNTIME,MulConstByFunTime);
      CAPD_EVALC0(NODE_MUL_TIME_BY_VAR,MulTimeByVar);
      CAPD_EVALC0(NODE_MUL_TIME_BY_FUNTIME,MulTimeByFunTime);
      CAPD_EVALC0(NODE_MUL_FUNTIME_BY_VAR,MulFunTimeByVar);
      CAPD_EVALC0(NODE_MUL_FUNTIME_BY_FUNTIME,MulFunTimeByFunTime);

      CAPD_EVALC0(NODE_DIV,Div);
      CAPD_EVALC0(NODE_DIV_VAR_BY_CONST,DivVarByConst);
      CAPD_EVALC0(NODE_DIV_VAR_BY_TIME,DivVarByTime);
      CAPD_EVALC0(NODE_DIV_VAR_BY_FUNTIME,DivVarByFunTime);
      CAPD_EVALC0(NODE_DIV_TIME_BY_CONST,DivTimeByConst);
      CAPD_EVALC0(NODE_DIV_FUNTIME_BY_CONST,DivFunTimeByConst);
      CAPD_EVALC0(NODE_DIV_FUNTIME_BY_TIME,DivFunTimeByTime);
      CAPD_EVALC0(NODE_DIV_FUNTIME_BY_FUNTIME,DivFunTimeByFunTime);
      CAPD_EVALC0(NODE_DIV_CONST_BY_CONST,DivConstByConst);

      CAPD_EVALC0(NODE_SQR,Sqr);
      CAPD_EVALC0(NODE_SQR_CONST,SqrConst);
      CAPD_EVALC0(NODE_SQR_TIME,SqrTime);
      CAPD_EVALC0(NODE_SQR_FUNTIME,SqrFunTime);
      CAPD_EVALC0(NODE_SQRT,Sqrt);
      CAPD_EVALC0(NODE_SQRT_CONST,SqrtConst);
      CAPD_EVALC0(NODE_SQRT_TIME,SqrtTime);
      CAPD_EVALC0(NODE_SQRT_FUNTIME,SqrtFunTime);

      CAPD_EVALC0(NODE_SIN,Sin);
      CAPD_EVALC0(NODE_SIN_CONST,SinConst);
      CAPD_EVALC0(NODE_SIN_TIME,SinTime);
      CAPD_EVALC0(NODE_SIN_FUNTIME,SinFunTime);

      CAPD_EVALC0(NODE_EXP,Exp);
      CAPD_EVALC0(NODE_EXP_CONST,ExpConst);
      CAPD_EVALC0(NODE_EXP_TIME,ExpTime);
      CAPD_EVALC0(NODE_EXP_FUNTIME,ExpFunTime);

      CAPD_EVALC0(NODE_LOG,Log);
      CAPD_EVALC0(NODE_LOG_CONST,LogConst);
      CAPD_EVALC0(NODE_LOG_TIME,LogTime);
      CAPD_EVALC0(NODE_LOG_FUNTIME,LogFunTime);
    default:
      std::cout << "missed node code: " << b->op << std::endl;
      throw std::logic_error("Some node is missed in switch-case in function eval! Implementation error!");
}
#else
    Eval<Scalar>::c0f[b->op](left,right,result,coeffNo);
#endif
  }
}
// ---------------------------------------------------------------------

template<class Scalar>
void evalHomogenousPolynomial(const std::vector<MyNode>& nodes, JetSize jetSize, Scalar* data)
{
  typename std::vector<MyNode>::const_iterator b = nodes.begin(), e = nodes.end();
  for(;b!=e;++b)
  {
    Scalar* left = data + jetSize*b->left;
    Scalar* right = data + jetSize*b->right;
    Scalar* result = data + jetSize*b->result;
#ifdef CAPD_USE_MACROS
    switch(b->op)
    {
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_ADD,Add);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_CONST_PLUS_VAR,ConstPlusVar);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_CONST_PLUS_CONST,ConstPlusConst);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_CONST_PLUS_TIME,ConstPlusTime);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_CONST_PLUS_FUNTIME,ConstPlusFunTime);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_TIME_PLUS_VAR,TimePlusVar);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_TIME_PLUS_FUNTIME,TimePlusFunTime);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_FUNTIME_PLUS_VAR,FunTimePlusVar);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_FUNTIME_PLUS_FUNTIME,FunTimePlusFunTime);

      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_SUB,Sub);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_CONST_MINUS_CONST,ConstMinusConst);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_CONST_MINUS_VAR,ConstMinusVar);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_CONST_MINUS_TIME,ConstMinusTime);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_CONST_MINUS_FUNTIME,ConstMinusFunTime);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_TIME_MINUS_CONST,TimeMinusConst);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_TIME_MINUS_FUNTIME,TimeMinusFunTime);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_TIME_MINUS_VAR,TimeMinusVar);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_FUNTIME_MINUS_CONST,FunTimeMinusConst);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_FUNTIME_MINUS_TIME,FunTimeMinusTime);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_FUNTIME_MINUS_FUNTIME,FunTimeMinusFunTime);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_FUNTIME_MINUS_VAR,FunTimeMinusVar);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_VAR_MINUS_CONST,VarMinusConst);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_VAR_MINUS_TIME,VarMinusTime);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_VAR_MINUS_FUNTIME,VarMinusFunTime);

      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_UNARY_MINUS,UnaryMinus);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_UNARY_MINUS_CONST,UnaryMinusConst);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_UNARY_MINUS_TIME,UnaryMinusTime);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_UNARY_MINUS_FUNTIME,UnaryMinusFunTime);

      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_MUL,Mul);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_MUL_CONST_BY_VAR,MulConstByVar);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_MUL_CONST_BY_CONST,MulConstByConst);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_MUL_CONST_BY_TIME,MulConstByTime);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_MUL_CONST_BY_FUNTIME,MulConstByFunTime);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_MUL_TIME_BY_VAR,MulTimeByVar);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_MUL_TIME_BY_FUNTIME,MulTimeByFunTime);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_MUL_FUNTIME_BY_VAR,MulFunTimeByVar);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_MUL_FUNTIME_BY_FUNTIME,MulFunTimeByFunTime);

      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_DIV,Div);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_DIV_VAR_BY_CONST,DivVarByConst);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_DIV_VAR_BY_TIME,DivVarByTime);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_DIV_VAR_BY_FUNTIME,DivVarByFunTime);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_DIV_TIME_BY_CONST,DivTimeByConst);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_DIV_FUNTIME_BY_CONST,DivFunTimeByConst);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_DIV_FUNTIME_BY_TIME,DivFunTimeByTime);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_DIV_FUNTIME_BY_FUNTIME,DivFunTimeByFunTime);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_DIV_CONST_BY_CONST,DivConstByConst);

      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_SQR,Sqr);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_SQR_CONST,SqrConst);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_SQR_TIME,SqrTime);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_SQR_FUNTIME,SqrFunTime);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_SQRT,Sqrt);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_SQRT_CONST,SqrtConst);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_SQRT_TIME,SqrtTime);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_SQRT_FUNTIME,SqrtFunTime);

      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_SIN,Sin);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_SIN_CONST,SinConst);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_SIN_TIME,SinTime);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_SIN_FUNTIME,SinFunTime);

      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_EXP,Exp);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_EXP_CONST,ExpConst);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_EXP_TIME,ExpTime);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_EXP_FUNTIME,ExpFunTime);

      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_LOG,Log);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_LOG_CONST,LogConst);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_LOG_TIME,LogTime);
      CAPD_EVAL_C0HOMOGENOUS_POLYNOMIAL(NODE_LOG_FUNTIME,LogFunTime);
    default:
      std::cout << "missed node code: " << b->op << std::endl;
      throw std::logic_error("Some node is missed in switch-case in function eval! Implementation error!");
}
#else
    Eval<Scalar>::c0hf[b->op](left,right,result);
#endif
  }
}


// ---------------------------------------------------------------------

template<class Scalar>
void evalHomogenousPolynomial(int degree, const std::vector<MyNode>& nodes, int dim, Order order, JetSize jetSize, Scalar* data)
{
  typename std::vector<MyNode>::const_iterator b = nodes.begin(), e = nodes.end();
  for(;b!=e;++b)
  {
    Scalar* left = data + jetSize*b->left;
    Scalar* right = data + jetSize*b->right;
    Scalar* result = data + jetSize*b->result;
#ifdef CAPD_USE_MACROS
    switch(b->op)
    {
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_ADD,Add);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_CONST_PLUS_VAR,ConstPlusVar);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_CONST_PLUS_CONST,ConstPlusConst);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_CONST_PLUS_TIME,ConstPlusTime);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_CONST_PLUS_FUNTIME,ConstPlusFunTime);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_TIME_PLUS_VAR,TimePlusVar);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_TIME_PLUS_FUNTIME,TimePlusFunTime);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_FUNTIME_PLUS_VAR,FunTimePlusVar);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_FUNTIME_PLUS_FUNTIME,FunTimePlusFunTime);

      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_SUB,Sub);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_CONST_MINUS_CONST,ConstMinusConst);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_CONST_MINUS_VAR,ConstMinusVar);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_CONST_MINUS_TIME,ConstMinusTime);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_CONST_MINUS_FUNTIME,ConstMinusFunTime);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_TIME_MINUS_CONST,TimeMinusConst);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_TIME_MINUS_FUNTIME,TimeMinusFunTime);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_TIME_MINUS_VAR,TimeMinusVar);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_FUNTIME_MINUS_CONST,FunTimeMinusConst);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_FUNTIME_MINUS_TIME,FunTimeMinusTime);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_FUNTIME_MINUS_FUNTIME,FunTimeMinusFunTime);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_FUNTIME_MINUS_VAR,FunTimeMinusVar);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_VAR_MINUS_CONST,VarMinusConst);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_VAR_MINUS_TIME,VarMinusTime);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_VAR_MINUS_FUNTIME,VarMinusFunTime);

      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_UNARY_MINUS,UnaryMinus);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_UNARY_MINUS_CONST,UnaryMinusConst);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_UNARY_MINUS_TIME,UnaryMinusTime);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_UNARY_MINUS_FUNTIME,UnaryMinusFunTime);

      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_MUL,Mul);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_MUL_CONST_BY_VAR,MulConstByVar);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_MUL_CONST_BY_CONST,MulConstByConst);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_MUL_CONST_BY_TIME,MulConstByTime);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_MUL_CONST_BY_FUNTIME,MulConstByFunTime);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_MUL_TIME_BY_VAR,MulTimeByVar);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_MUL_TIME_BY_FUNTIME,MulTimeByFunTime);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_MUL_FUNTIME_BY_VAR,MulFunTimeByVar);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_MUL_FUNTIME_BY_FUNTIME,MulFunTimeByFunTime);

      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_DIV,Div);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_DIV_VAR_BY_CONST,DivVarByConst);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_DIV_VAR_BY_TIME,DivVarByTime);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_DIV_VAR_BY_FUNTIME,DivVarByFunTime);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_DIV_TIME_BY_CONST,DivTimeByConst);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_DIV_FUNTIME_BY_CONST,DivFunTimeByConst);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_DIV_FUNTIME_BY_TIME,DivFunTimeByTime);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_DIV_FUNTIME_BY_FUNTIME,DivFunTimeByFunTime);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_DIV_CONST_BY_CONST,DivConstByConst);

      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_SQR,Sqr);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_SQR_CONST,SqrConst);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_SQR_TIME,SqrTime);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_SQR_FUNTIME,SqrFunTime);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_SQRT,Sqrt);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_SQRT_CONST,SqrtConst);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_SQRT_TIME,SqrtTime);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_SQRT_FUNTIME,SqrtFunTime);

      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_SIN,Sin);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_SIN_CONST,SinConst);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_SIN_TIME,SinTime);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_SIN_FUNTIME,SinFunTime);

      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_EXP,Exp);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_EXP_CONST,ExpConst);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_EXP_TIME,ExpTime);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_EXP_FUNTIME,ExpFunTime);

      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_LOG,Log);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_LOG_CONST,LogConst);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_LOG_TIME,LogTime);
      CAPD_EVAL_HOMOGENOUS_POLYNOMIAL(NODE_LOG_FUNTIME,LogFunTime);
    default:
      std::cout << "missed node code: " << b->op << std::endl;
      throw std::logic_error("Some node is missed in switch-case in function eval! Implementation error!");
}

#else
    Eval<Scalar>::hf[b->op](degree,left,right,result,dim,order);
#endif
  }
}

}} // namespace capd::autodiff

#endif
