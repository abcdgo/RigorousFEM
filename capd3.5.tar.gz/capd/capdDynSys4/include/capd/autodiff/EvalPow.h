/// @addtogroup autodiff
/// @{

/////////////////////////////////////////////////////////////////////////////
/// @file EvalPow.h
///
/// @author Daniel Wilczak
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) 2000-2012 by the CAPD Group.
//
// This file constitutes a part of the CAPD library,
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.ii.uj.edu.pl/ for details.

#ifndef _CAPD_AUTODIFF_EVAL_POW_H_
#define _CAPD_AUTODIFF_EVAL_POW_H_

#include "capd/autodiff/NodeType.h"

namespace capd{
namespace autodiff{

// -------------------- Pow ------------------------------------

namespace Pow
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    T c = *right;
    T u = *left;
    if(coeffNo)
    {
      register T temp = capd::TypeTraits<T>::zero();
      for(int j=0;j<coeffNo;++j)
        temp += (c*((int)coeffNo-j)-j) * result[j] *left[coeffNo-j];
      result[coeffNo] = temp/((double)coeffNo * u);
    }
    else
      *result = exp(c * log(u));
  }

  template<class T>
  inline void evalC1(T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);

    T* leftDer = left + order;
    T* resultDer = result + order;
    for(int derNo=0;derNo<dim;++derNo,leftDer+=order,resultDer+=order)
    {
      register T temp1 = result[coeffNo] * (*leftDer);
      register T temp2 = capd::TypeTraits<T>::zero();
      for(int j=0;j<coeffNo;++j)
      {
        temp1 += result[j] * leftDer[coeffNo-j];
        temp2 += left[coeffNo-j] * resultDer[j];
      }
      resultDer[coeffNo] = (temp1*(*right)-temp2)/(*left);
    }
  } // evalC1

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    switch(degree)
    {
      case 1:
        evalC1(left,right,result,dim,order,coeffNo);
        break;
      case 0:
        evalC0(left,right,result,coeffNo);
        break;
      default:
        throw std::logic_error("Jet propagation of Power is not implemented for degree>1");
    }
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = exp((*right) * log(*left));
  }

  template<class T>
  inline void evalC1HomogenousPolynomial(T* left, T* right, T* result, int dim, Order order)
  {
    T* leftDer = left + order;
    T* resultDer = result + order;
    T t = (*result)*(*right)/(*left);
    for(int derNo=0;derNo<dim;++derNo,leftDer+=order,resultDer+=order)
    {
      *resultDer = t*(*leftDer);
    }
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {
    switch(degree)
    {
      case 1:
        evalC1HomogenousPolynomial(left,right,result,dim,order);
        break;
      case 0:
        evalC0HomogenousPolynomial(left,right,result);
        break;
      default:
        throw std::logic_error("Jet propagation of Power is not implemented for degree>1");
    }
  }
}

// -------------------- PowFunTime ------------------------------------

namespace PowFunTime
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    Pow::evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    Pow::evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = exp((*right) * log(*left));
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}
}

// -------------------- PowTime ------------------------------------

namespace PowTime
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    if(coeffNo)
      result[coeffNo] = ((*right)-(coeffNo-1)) * result[coeffNo-1]/((double)coeffNo * (*left));
    else
      *result = exp((*right) * log((*left)));
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = exp((*right) * log(*left));
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}
}

// -------------------- PowConst ------------------------------------

namespace PowConst
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    if(coeffNo)
      {}
    else
      *result = exp((*right) * log(*left));
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = exp((*right) * log(*left));
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}
}

// ----------------------------------------------------------------------------------

//use macro to define classes

CAPD_MAKE_CLASS_NODE(Pow);
CAPD_MAKE_CLASS_NODE(PowConst);
CAPD_MAKE_CLASS_NODE(PowTime);
CAPD_MAKE_CLASS_NODE(PowFunTime);

}} // namespace capd::autodiff

#endif
