/// @addtogroup autodiff
/// @{

/////////////////////////////////////////////////////////////////////////////
/// @file EvalExp.h
///
/// @author Daniel Wilczak
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) 2000-2012 by the CAPD Group.
//
// This file constitutes a part of the CAPD library,
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.ii.uj.edu.pl/ for details.

#ifndef _CAPD_AUTODIFF_EVAL_EXP_H_
#define _CAPD_AUTODIFF_EVAL_EXP_H_

#include "capd/autodiff/NodeType.h"

namespace capd{
namespace autodiff{

// -------------------- Exp ------------------------------------

namespace Exp
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    if(coeffNo)
    {
      register T temp = TypeTraits<T>::zero();
      for(int j=0;j<coeffNo;++j)
        temp += double(coeffNo-j) * result[j]*left[coeffNo-j];
      result[coeffNo] = temp/(double)coeffNo;
    }else
      *result = exp(*left);
  }

  template<class T>
  inline void evalC1(T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);
    // shift pointers to proper coefficients
    T* resultDer = result + order + coeffNo;
    T* leftDer = left + order;

    for(int derNo=0;derNo<=dim;++derNo,resultDer+=order, leftDer+=order)
    {
      register T temp = capd::TypeTraits<T>::zero();
      for(int j=0;j<=coeffNo;++j)
        temp += leftDer[coeffNo-j] * result[j];
      *resultDer = temp;
    }
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    switch(degree)
    {
      case 1:
        evalC1(left,right,result,dim,order,coeffNo);
        break;
      case 0:
        evalC0(left,right,result,coeffNo);
        break;
      default:
        throw std::logic_error("Jet propagation of exponent is not implemented for degree>1");
    }
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = exp(*left);
  }

  template<class T>
  inline void evalC1HomogenousPolynomial(T* left, T* right, T* result, int dim, Order order)
  {
    T* resultDer = result + order;
    T* leftDer = left + order;

    for(int derNo=0;derNo<=dim;++derNo,resultDer+=order, leftDer+=order)
      *resultDer = (*leftDer) * (*result);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {
    switch(degree)
    {
      case 1:
        evalC1HomogenousPolynomial(left,right,result,dim,order);
        break;
      case 0:
        evalC0HomogenousPolynomial(left,right,result);
        break;
      default:
        throw std::logic_error("Jet propagation of exponent is not implemented for degree>1");
    }
  }
}

namespace ExpFunTime
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    Exp::evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    Exp::evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = exp(*left);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}
}

namespace ExpTime
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    if(coeffNo)
      result[coeffNo] = result[coeffNo-1]/(double)coeffNo;
    else
      *result = exp(*left);
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = exp(*left);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}
}

namespace ExpConst
{
  template<class T>
  inline void evalC0(T* left, T* right, T* result, CoeffNo coeffNo)
  {
    if(coeffNo)
      {}
    else
      *result = exp(*left);
  }

  template<class T>
  inline void eval(int degree, T* left, T* right, T* result, int dim, Order order, CoeffNo coeffNo)
  {
    evalC0(left,right,result,coeffNo);
  }

  template<class T>
  inline void evalC0HomogenousPolynomial(T* left, T* right, T* result)
  {
    *result = exp(*left);
  }

  template<class T>
  inline void evalHomogenousPolynomial(int degree, T* left, T* right, T* result, int dim, Order order)
  {}
}

// ----------------------------------------------------------------------------------

//use macro to define classes

CAPD_MAKE_CLASS_NODE(Exp);
CAPD_MAKE_CLASS_NODE(ExpConst);
CAPD_MAKE_CLASS_NODE(ExpTime);
CAPD_MAKE_CLASS_NODE(ExpFunTime);

}} // namespace capd::autodiff

#endif
