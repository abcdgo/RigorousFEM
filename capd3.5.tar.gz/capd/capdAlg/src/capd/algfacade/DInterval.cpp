/////////////////////////////////////////////////////////////////////////////
/// @file algfacade/DInterval.cpp
///
/// @author kapela
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) 2008 by the CAPD Group.
//
// Distributed under the terms of the GNU General Public License.
// Consult  http://capd.wsb-nlu.edu.pl/ for details.

// Created on 4 maj 2008, 07:44

#include "capd/facade/DInterval.h"
