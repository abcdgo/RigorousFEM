
/////////////////////////////////////////////////////////////////////////////
/// @file vectalg/IVector.cpp
///
/// @author The CAPD Group
/////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2000-2005 by the CAPD Group.
//
// This file constitutes a part of the CAPD library, 
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.wsb-nlu.edu.pl/ for details. 

#include <iostream>

#include "capd/vectalg/Dimension.h"
#include "capd/vectalg/Vector.hpp"
#include "capd/intervals/lib.h"

namespace capd{ 
  namespace vectalg{


template class Vector<Interval,CAPD_DEFAULT_DIMENSION>;

template Vector<Interval,CAPD_DEFAULT_DIMENSION> abs<Interval,CAPD_DEFAULT_DIMENSION> (const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v);
template Vector<Interval,CAPD_DEFAULT_DIMENSION> operator- <Interval,CAPD_DEFAULT_DIMENSION> (const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v);
template Vector<Interval,CAPD_DEFAULT_DIMENSION> operator+ <Interval,CAPD_DEFAULT_DIMENSION>(const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v1,const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v2);
template Vector<Interval,CAPD_DEFAULT_DIMENSION> operator- <Interval,CAPD_DEFAULT_DIMENSION>(const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v1,const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v2);
template Interval operator* <Interval,CAPD_DEFAULT_DIMENSION> (const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v1,const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v2);

template Vector<Interval,CAPD_DEFAULT_DIMENSION> operator* <Interval,Interval,CAPD_DEFAULT_DIMENSION>(const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v,const Interval &s);
template Vector<Interval,CAPD_DEFAULT_DIMENSION> operator* <Interval,Interval,CAPD_DEFAULT_DIMENSION>(const Interval &s,const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v);
template Vector<Interval,CAPD_DEFAULT_DIMENSION> operator/ <Interval,Interval,CAPD_DEFAULT_DIMENSION>(const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v, const Interval &s);

template Vector<Interval,CAPD_DEFAULT_DIMENSION> operator* <Interval,double,CAPD_DEFAULT_DIMENSION>(const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v,const double &s);
template Vector<Interval,CAPD_DEFAULT_DIMENSION> operator* <Interval,double,CAPD_DEFAULT_DIMENSION>(const double &s,const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v);
template Vector<Interval,CAPD_DEFAULT_DIMENSION> operator/ <Interval,double,CAPD_DEFAULT_DIMENSION>(const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v, const double &s);

template Vector<Interval,CAPD_DEFAULT_DIMENSION> operator* <Interval,long,CAPD_DEFAULT_DIMENSION>(const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v,const long &s);
template Vector<Interval,CAPD_DEFAULT_DIMENSION> operator* <Interval,long,CAPD_DEFAULT_DIMENSION>(const long &s,const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v);
template Vector<Interval,CAPD_DEFAULT_DIMENSION> operator/ <Interval,long,CAPD_DEFAULT_DIMENSION>(const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v, const long &s);

template Vector<Interval,CAPD_DEFAULT_DIMENSION> operator* <Interval,int,CAPD_DEFAULT_DIMENSION>(const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v,const int &s);
template Vector<Interval,CAPD_DEFAULT_DIMENSION> operator* <Interval,int,CAPD_DEFAULT_DIMENSION>(const int &s,const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v);
template Vector<Interval,CAPD_DEFAULT_DIMENSION> operator/ <Interval,int,CAPD_DEFAULT_DIMENSION>(const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v, const int &s);

template Vector<Interval,CAPD_DEFAULT_DIMENSION> operator+ <Interval,CAPD_DEFAULT_DIMENSION> (const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v, const Interval &s);
template Vector<Interval,CAPD_DEFAULT_DIMENSION> operator- <Interval,CAPD_DEFAULT_DIMENSION>(const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v,const Interval &s);
template bool operator < <Interval,CAPD_DEFAULT_DIMENSION> (const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v1,const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v2);
template bool operator > <Interval,CAPD_DEFAULT_DIMENSION> (const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v1,const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v2);
template bool operator<= <Interval,CAPD_DEFAULT_DIMENSION> (const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v1,const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v2);
template bool operator>= <Interval,CAPD_DEFAULT_DIMENSION> (const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v1,const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v2);
template std::ostream &operator<< <Interval,CAPD_DEFAULT_DIMENSION> (std::ostream &out, const Vector<Interval,CAPD_DEFAULT_DIMENSION> &v);
template std::istream &operator>> <Interval,CAPD_DEFAULT_DIMENSION>(std::istream &inp, Vector<Interval,CAPD_DEFAULT_DIMENSION> &v);

template void subtractObjects<>(const Vector<Interval,CAPD_DEFAULT_DIMENSION>& v1,const Vector<Interval,CAPD_DEFAULT_DIMENSION>& v2, Vector<Interval,CAPD_DEFAULT_DIMENSION>& result);
template void addObjects<>(const Vector<Interval,CAPD_DEFAULT_DIMENSION>& v1,const Vector<Interval,CAPD_DEFAULT_DIMENSION>& v2, Vector<Interval,CAPD_DEFAULT_DIMENSION>& result);


typedef Vector<Interval,CAPD_DEFAULT_DIMENSION> IVector;
typedef Vector<Interval::BoundType,CAPD_DEFAULT_DIMENSION> DVector;

template IVector intervalHull<IVector>(const IVector &A, const IVector &B);
template void split<IVector,IVector>(IVector& v, IVector& rv);
template void split<IVector,DVector>(const IVector& v, DVector&, IVector& rv);
template IVector midVector<IVector>(const IVector& v);
template IVector leftVector<IVector>(const IVector& v);
template IVector rightVector<IVector>(const IVector& v);
template Interval size<IVector>(const IVector& v);
template IVector diam<IVector>(const IVector& v);
template IVector intervalBall<IVector>(const IVector &iv, const Interval &r);
template Interval solveAffineInclusion<IVector>(const IVector& a,const IVector& p,const IVector& c);
template Interval solveAffineInclusion<IVector>(const IVector& a,const IVector& p,const IVector& c,int&);
template bool subset<IVector>(const IVector& v1, const IVector& v2);
template bool subsetInterior<IVector>(const IVector& v1, const IVector& v2);
template IVector intersection<IVector>(const IVector &v1, const IVector &v2);
template std::string vectorToString<IVector>( const IVector & v, int firstIndex , int lastIndex , int precision);
template std::ostream & printVector<IVector>(std::ostream & str, const IVector & v, int firstIndex, int lastIndex);

  }}  // end of namespace capd::vectalg

