/////////////////////////////////////////////////////////////////////////////
/// @file IntervalOld.h
///
/// @deprecated
/// @author Tomasz Kapela   @date 09-12-2006
/////////////////////////////////////////////////////////////////////////////

// Copyright (C) Tomasz Kapela 2006
//
// This file constitutes a part of the CAPD library, 
// distributed under the terms of the GNU General Public License.
// Consult  http://capd.wsb-nlu.edu.pl/ for details. 

#ifndef _CAPD_INTERVAL_INTERVALOLD_H_ 
#define _CAPD_INTERVAL_INTERVALOLD_H_ 

#define __INTERVAL_DEPRECATED__

#include "capd/intervals/DoubleInterval.h"


#endif // _CAPD_INTERVAL_INTERVALOLD_H_ 
