/*
 * gtestHeader.h
 *
 *  Created on: 2009-09-02
 *      Author: iikapela
 */

#ifndef _UNITTESTS_GTESTHEADER_H_
#define _UNITTESTS_GTESTHEADER_H_
#include "gtest/gtest.h"

#endif /* _UNITTESTS_GTESTHEADER_H_ */
